title: elk安装以及使用
date: '2019-10-31 09:34:07'
updated: '2019-10-31 09:34:07'
tags: [elasticsearch, logstash, kinan]
permalink: /articles/2019/10/31/1572485647330.html
---
![](https://img.hacpai.com/bing/20190116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

elk安装以及使用

说明，以下配置按照业务日志打印格式为json，并且每行json格式为完整json，若不是单行完整json，或者其他格式日志参考multiline使用方式，进行多行合并

               codec => multiline {

                  pattern => "^{"

                  negate => true

                  what => previous

                }

日志统一的好处：不需要写复杂正则进行匹配，相比json数据正则占用cpu消耗更大
log4j2能直接发送到logstash弊端也比较明显，日志配置有更改地址及端口能尝试

log4j2日志配置单行完整json配置文件：

    <?xml version="1.0" encoding="UTF-8"?>
    <!--日志级别以及优先级排序: OFF > FATAL > ERROR > WARN > INFO > DEBUG > TRACE > ALL -->
    <!--Configuration后面的status，这个用于设置log4j2自身内部的信息输出，可以不设置，当设置成trace时，你会看到log4j2内部各种详细输出-->
    <!--monitorInterval：Log4j能够自动检测修改配置 文件和重新配置本身，设置间隔秒数-->
    <configuration status="WARN" monitorInterval="60">
        <Properties>
        		<Property name="log.dir" value="/data/applog" />
        		<Property name="max" value="20" />
        		<Property name="age" value="15d" />
        		<Property name="SizeBasedTriggeringPolicySize" value="1024MB" />
        		
      	</Properties>
    
        <appenders>
            <console name="Console" target="SYSTEM_OUT">
            		<ThresholdFilter level="DEBUG" onMatch="ACCEPT" onMismatch="NEUTRAL"/>
                <JsonLayout  compact="true" eventEol="true" />
            </console>
            
          <!--   <Socket name="Logstash" host="192.168.20.101" port="9601" protocol="TCP">
                <PatternLayout pattern="${PATTERN}" />
                <JsonLayout compact="true" eventEol="true" />
            </Socket> -->
            
            <RollingFile name="RollingFileDebug" fileName="${log.dir}/debug.log" filePattern="${log.dir}/debug.log.%d{yyyy-MM-dd}.%i.gz">
                <Filters>
                    <ThresholdFilter level="DEBUG" onMatch="ACCEPT" onMismatch="DENY"/>
                </Filters>
                <JsonLayout  compact="true" eventEol="true" />
                <Policies>
                    <TimeBasedTriggeringPolicy/>
                    <SizeBasedTriggeringPolicy size="${SizeBasedTriggeringPolicySize}"/>
                </Policies>
    		 <!-- max 最多几个文件   basePath 日志文件位置  glob目标文件规则   age最多保存多少天数据  -->
    		  <DefaultRolloverStrategy max="${max}">
    		  		<Delete basePath="${log.dir}" maxDepth="1">
    		  			<IfFileName glob="debug*.gz"/>
    		  			<IfLastModified age="${age}"/>
    		  		</Delete>
    		  		
    		  </DefaultRolloverStrategy>
            </RollingFile>
    
            <RollingFile name="RollingFileInfo" fileName="${log.dir}/info.log" filePattern="${log.dir}/info-%d{yyyy-MM-dd}-%i.gz">
                <Filters>
                    <ThresholdFilter level="INFO" onMatch="ACCEPT" onMismatch="DENY"/>
                </Filters>
                <JsonLayout  compact="true" eventEol="true" />
                <Policies>
                    <TimeBasedTriggeringPolicy/>
                    <SizeBasedTriggeringPolicy size="${SizeBasedTriggeringPolicySize}"/>
                </Policies>
                	 <!-- max 最多几个文件   basePath 日志文件位置  glob目标文件规则   age最多保存多少天数据  -->
    		  <DefaultRolloverStrategy max="${max}">
    		  		<Delete basePath="${log.dir}" maxDepth="1">
    		  			<IfFileName glob="info*.gz"/>
    		  			<IfLastModified age="${age}"/>
    		  		</Delete>
    		  		
    		  </DefaultRolloverStrategy>
            </RollingFile>
    
            <RollingFile name="RollingFileWarn" fileName="${log.dir}/warn.log" filePattern="${log.dir}/warn-%d{yyyy-MM-dd}-%i.gz">
                <Filters>
                    <ThresholdFilter level="WARN" onMatch="ACCEPT" onMismatch="DENY"/>
                </Filters>
                <JsonLayout  compact="true" eventEol="true" />
                <Policies>
                    <TimeBasedTriggeringPolicy/>
                    <SizeBasedTriggeringPolicy size="${SizeBasedTriggeringPolicySize}"/>
                </Policies>
                	 <!-- max 最多几个文件   basePath 日志文件位置  glob目标文件规则   age最多保存多少天数据  -->
    		  <DefaultRolloverStrategy max="${max}">
    		  		<Delete basePath="${log.dir}" maxDepth="1">
    		  			<IfFileName glob="warn*.gz"/>
    		  			<IfLastModified age="${age}"/>
    		  		</Delete>
    		  		
    		  </DefaultRolloverStrategy>
            </RollingFile>
    
            <RollingFile name="RollingFileError" fileName="${log.dir}/error.log" filePattern="${log.dir}/error-%d{yyyy-MM-dd}-%i.gz">
            	<Filters>
            		<ThresholdFilter level="ERROR" onMatch="ACCEPT" onMismatch="DENY"/>
            	</Filters>
                <JsonLayout  compact="true" eventEol="true" />
                <Policies>
                    <TimeBasedTriggeringPolicy/>
                    <SizeBasedTriggeringPolicy size="${SizeBasedTriggeringPolicySize}"/>
                </Policies>
                	 <!-- max 最多几个文件   basePath 日志文件位置  glob目标文件规则   age最多保存多少天数据  -->
    		  <DefaultRolloverStrategy max="${max}">
    		  		<Delete basePath="${log.dir}" maxDepth="1">
    		  			<IfFileName glob="error*.gz"/>
    		  			<IfLastModified age="${age}"/>
    		  		</Delete>
    		  		
    		  </DefaultRolloverStrategy>
            </RollingFile>
    
      
             
        </appenders>
    
        <loggers>
            <root level="DEBUG">
                <appender-ref ref="Console"/>
                <appender-ref ref="RollingFileDebug"/>
                <!-- <appender-ref ref="Logstash" /> -->
                <appender-ref ref="RollingFileInfo"/>
                <appender-ref ref="RollingFileWarn"/>
                <appender-ref ref="RollingFileError"/>
            </root>
    	        
        </loggers>
    
    </configuration>



一、elasticsearch安装

1、下载elasticsearch5.6.10

wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-5.6.10.tar.gz

2、解压elasticsearch-5-6-10并修改配置文件

tar -zxvf elasticsearch-5-6-10
cd elasticsearch-5-6-10/config
 修改elasticsearch.yml添加如下配置

    cluster.name: escluster
    node.name: node-01
    node.data: true
    network.host: 0.0.0.0 #内网ip
    http.port: 9991
    transport.tcp.port: 9992
    discovery.zen.ping.unicast.hosts: ["node-1:9992","node-2:9992","node-3:9992"]
    http.cors.enabled: true
    http.cors.allow-origin: "*"
    bootstrap.system_call_filter: true
    bootstrap.memory_lock: true #设置为true必须在系统设置  vi /etc/fstab   注释掉包含该单词的行swap
    discovery.zen.minimum_master_nodes: 2
    

3、创建用户以及日志和数据文件夹

创建组

useradd esuser

创建用户 esuser

设置密码

passwd esuser

更改目录权限

chown esuser: esuser elasticsearch-5.6.10 -R

进入elasticsearch根目录 创建logs目录和data目录

chmod -R 777 logs    chmod -R 777 data

不执行以上命令 则会启动报错

./bin/elasticsearch -d 后台启动

netstat  -anp  |grep  9991

访问http://node-1:9991是否可以访问

停止es： 

           kill -SIGTERM pid

 

4、遇到问题

1）、启动 elasticsearch 如出现异常  can not run elasticsearch as root  

解决方法：创建ES 账户，修改文件夹 文件 权限

2）、启动异常：ERROR: bootstrap checks failed

system call filters failed to install; check the logs and fix your configuration or disable system call filters at your own risk

问题原因：因为Centos6不支持SecComp，而ES6.2.4默认bootstrap.system_call_filter为true进行检测，所以导致检测失败，失败后直接导致ES不能启动。详见 ：https://github.com/elastic/elasticsearch/issues/22899

解决方法：在elasticsearch.yml中配置bootstrap.system_call_filter为false，注意要在Memory下面:

bootstrap.memory_lock: false

bootstrap.system_call_filter: false

3）、max virtual memory areas vm.max_map_count [65536] is too low, increase to at least [262144]

解决：

sysctl -w vm.max_map_count=262144

sysctl -a | grep "vm.max_map_count"

4）、max number of threads [1024] for user [elasticsearch] is too low, increase to at least [2048]

解决：

vim /etc/security/limits.d/90-nproc.conf

添加

- soft    nproc     4096

5）、max file descriptors [4096] for elasticsearch process is too low, increase to at least [65536]

解决：

vi /etc/security/limits.conf

添加如下内容:

* soft nofile 65536

* hard nofile 131072

* soft nproc 2048

* hard nproc 4096

6）、system call filters failed to install; check the logs and fix your configuration or disable system call filters at your own risk

解决： 

在elasticsearch.yml中添加配置bootstrap.system_call_filter: false

7)、安装search-guard插件后，es-head插件获取不到集群信息

解决：修改http.cors.allow-headers参数

http.cors.allow-headers:Authorization,X-Requested-With,Content-Length,Content-Type

5、插件安装

1）、elasticsearch-head 安装

       1.安装nodejs环境

       1) wget https://npm.taobao.org/mirrors/node/latest-v4.x/node-v4.4.7-linux-x64.tar.gz

2) tar -zxvf node-v4.4.7-linux-x64.tar.gz

3) 设置环境变量 export PATH=$PATH:/usr/nodejs/node-v9.9.0-linux-x64/bin

       2.安装npm

下载nmp安装包，一般nodejs包中已经包含了，设置过环境变量就可以直接使用nmp命令了

3.安装elasticsearch-head 

1).下载插件

git clone git://github.com/mobz/elasticsearch-head.git

2）安装grunt

cd elasticsearch-head

 1）安装grunt命令行工具grunt-cli      npm install -g grunt-cli

 2）安装grunt及其插件                npm install grunt --save-dev

3).执行npm命令

cd elasticsearch-head

执行：

    npm install cnpm -g --registry=https://registry.npm.taobao.org
    npm install grunt-contrib-clean --registry=https://registry.npm.taobao.org
    npm install grunt-contrib-concat --registry=https://registry.npm.taobao.org
    npm install grunt-contrib-watch --registry=https://registry.npm.taobao.org 
    npm install grunt-contrib-connect --registry=https://registry.npm.taobao.org 
    npm install grunt-contrib-copy --registry=https://registry.npm.taobao.org 
    npm install grunt-contrib-jasmine --registry=https://registry.npm.taobao.org
    

       4).修改服务器监听端口

修改elasticsearch-head下Gruntfile.js文件，默认监听在127.0.0.1下9200端口，

打开elasticsearch-head-master/Gruntfile.js，找到下面connect属性，新增hostname: ‘0.0.0.0’:

    connect: {
    
            server: {
    
                options: {
    
                    hostname: '0.0.0.0',
    
                    port: 9100,
    
                    base: '.',
    
                    keepalive: true
    
                }
    
            }
    
        }

       5).启动head插件

然后cd /usr/local/elasticsearch-head  执行grunt server  或者  grunt server & 后台启动

浏览器访问 {ip}:9100/

6、index template 定义方式

 1)、logstash中定义logstash.json

    default 6.x index template
    {
      "index_patterns" : "wx*",
      "settings" : {
        "index.refresh_interval" : "5s"
      },
      "mappings" : {
        "_default_" : {
          "dynamic_templates" : [ {
            "message_field" : {
              "path_match" : "message",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text",
                "norms" : false
              }
            }
          }, {
            "string_fields" : {
              "match" : "*",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text", "norms" : false,
                "fields" : {
                  "keyword" : { "type": "keyword", "ignore_above": 256 }
                }
              }
            }
          } ],
          "properties" : {
            "@timestamp": { "type": "date"},
            "@version": { "type": "keyword"},
            "geoip": {
              "dynamic": true,
              "properties" : {
                "ip": { "type": "ip" },
                "location" : { "type" : "geo_point" },
                "latitude" : { "type" : "half_float" },
                "longitude" : { "type" : "half_float" }
              }
            }
          }
        }
      },
     "aliases" : {
            "wx" : {"wx"}
        }
    }
    
    default 5.x index template
    {
      "index_patterns" : "wx-*",
      "settings" : {
        "index.number_of_shards" : 2,
    	"index.number_of_replicas" : 1,
        "index.refresh_interval" : "5s"
      },
      "mappings" : {
        "_default_" : {
          "_all" : {"enabled" : true, "norms" : false},
          "dynamic_templates" : [ {
            "message_field" : {
              "path_match" : "message",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text",
                "norms" : false
              }
            }
          }, {
            "string_fields" : {
              "match" : "*",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text", "norms" : false,
                "fields" : {
                  "keyword" : { "type": "keyword", "ignore_above": 256 }
                }
              }
            }
          } ],
          "properties" : {
            "@timestamp": { "type": "date", "include_in_all": false },
            "@version": { "type": "keyword", "include_in_all": false },
            "geoip"  : {
              "dynamic": true,
              "properties" : {
                "ip": { "type": "ip" },
                "location" : { "type" : "geo_point" },
                "latitude" : { "type" : "half_float" },
                "longitude" : { "type" : "half_float" }
              }
            }
          }
        }
      }
      "aliases" : {
         "wx" : {"wx"}
      }
    }
    

  

 

2)、es中初始化

    default 6.x index template
    {
      "template" : "wx-*",
      "settings" : {
        "index.refresh_interval" : "5s"
      },
      "mappings" : {
        "_default_" : {
          "dynamic_templates" : [ {
            "message_field" : {
              "path_match" : "message",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text",
                "norms" : false
              }
            }
          }, {
            "string_fields" : {
              "match" : "*",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text", "norms" : false,
                "fields" : {
                  "keyword" : { "type": "keyword", "ignore_above": 256 }
                }
              }
            }
          } ],
          "properties" : {
            "@timestamp": { "type": "date"},
            "@version": { "type": "keyword"},
            "geoip": {
              "dynamic": true,
              "properties" : {
                "ip": { "type": "ip" },
                "location" : { "type" : "geo_point" },
                "latitude" : { "type" : "half_float" },
                "longitude" : { "type" : "half_float" }
              }
            }
          }
        }
      },
     "aliases" : {
            "wx" : {
    		 "wx":{}
    		}
        }
    }
    
    default 5.x index template
    {
      "template" : "wx-*",
      "order" : 0,
      "settings" : {
        "index.number_of_shards" : 2,
    	"index.number_of_replicas" : 1,
        "index.refresh_interval" : "5s"
      },
      "mappings" : {
        "_default_" : {
          "_all" : {"enabled" : true, "norms" : false},
          "dynamic_templates" : [ {
            "message_field" : {
              "path_match" : "message",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text",
                "norms" : false
              }
            }
          }, {
            "string_fields" : {
              "match" : "*",
              "match_mapping_type" : "string",
              "mapping" : {
                "type" : "text", "norms" : false,
                "fields" : {
                  "keyword" : { "type": "keyword", "ignore_above": 256 }
                }
              }
            }
          } ],
          "properties" : {
            "@timestamp": { "type": "date", "include_in_all": false },
            "@version": { "type": "keyword", "include_in_all": false },
            "geoip"  : {
              "dynamic": true,
              "properties" : {
                "ip": { "type": "ip" },
                "location" : { "type" : "geo_point" },
                "latitude" : { "type" : "half_float" },
                "longitude" : { "type" : "half_float" }
              }
            }
          }
        }
      },
     "aliases" : {
            "wx" : {"wx":{}}
        }
    }
    

   

7、head插件以及kibnan安全方式

1）、使用nginx  allow  （公司内部推荐）

2）、使用nginx base auth（公司内部推荐）

3)、x-pack 反编译类 （以后可以尝试）

4）、search Guard   https://search-guard.com/  （暂不考虑）

 

8、jvm.options设置jvm堆大小

经验总结：

1、 最小堆大小和最大堆大小设置相等

2、 es可用堆越多可用于缓存的内存越多，过多的堆会使es陷入长时间的垃圾收集暂停

3、 将Xmx设置为不超过物理RAM的50％，以确保有足够的物理RAM用于内核文件系统缓存

4、 不要将Xmx设置为JVM用于压缩对象指针（压缩oops）的最大值以上; 确切的最大值变化但接近32 GB。可以通过查找日志中的行来验证您是否在限制之下，如下所示：

heap size [1.9gb], compressed ordinary object pointers [true]

5、 尽量保持低于零基础压缩oops的阈值; 确切的截止值有所不同，但大多数系统上26 GB是安全的，但在某些系统上可能高达30 GB。您可以通过使用JVM选项启动Elasticsearch -XX:+UnlockDiagnosticVMOptions -XX:+PrintCompressedOopsMode 并查找如下所示的行来验证您是否在限制之下：

heap address: 0x000000011be00000, size: 27648 MB, zero based Compressed Oops

9、禁用禁用swapping

       Linux把它的物理内存划分为很多块, 称为页. 而Swapping则是把内存中的一页复制到磁盘上预定义空间的过程, 以释放更多的内存页, 而磁盘上的这部分空间称为交换区. 物理内存和交换区空间的总和称为虚拟内存空间.交换区并不总是有利的. 因为下内存相比, 磁盘总是慢太多. 通常内存的存储速度在纳秒级, 而磁盘却要毫秒级别. 所以磁盘的访问速度比直接访问内存要慢上万倍. 使用的交换空间越多, 系统会越多, 所以要避免交换区的使用.

linux下禁用所有swapping:

       sudo swapoff - a

检查mlockall：

GET _nodes?filter_path=**.mlockall

在es启动前执行：

ulimit -l unlimited

或者在/etc/security/limits.conf中设置memlock为unlimitedin 

二、logstash安装

1、下载logstash

       wget https://artifacts.elastic.co/downloads/logstash/logstash-5.6.10.tar.gz

2、解压 

       tar -zxvf logstash-5.6.10.tar.gz

3、启动

       cd logstash-5.6.10

       bin/logstash -e 'input { stdin { } } output { stdout {} }'    

       -e 指定字符串配置文件

       注：启动命令为bin/logstash <command> [arguments]

4、遇到问题

1、解压缩不完整，重新解压缩

       Unable to find JRuby.

       If you are a user, this is a bug.

       If you are a developer, please run 'rake bootstrap'. Running 'rake' requires the 'ruby' program be available.

2、普通用户启动,因为要记录日志

       Permission denied

       chmod -R 777 logstash-5.6.10(docker部署使用root发布)

3、logstash转义字符默认不开启，开启需要在logstash.yml中设置config.support_escapes: true

4、start_position => "beginning" 仅在该文件从未被监听过的时候起作用。如果 sincedb 文件中已经有这个文件的 inode 记录了，那么 logstash 依然会从记录过的 pos 开始读取数据。

       所以重复测试的时候每回需要删除 sincedb 文件(将sincedb_path 定义为 /dev/null ，则每次重启自动从头开始读)。

5、线上部署

1).每个node部署一个

2).启动指定配置文件用于全局统一配置

以下配置使用filebeats作为数据源进行数据输入 

    vi logstash.conf
    input {
        beats {
            port => "5044"
            codec => "json"
        }
    }
    filter {
      date {
        match => [ "timeMillis", "UNIX_MS"]
        target => "@timestamp"
      }
    }
    
    output { 
       elasticsearch {
            index => "%{project_name}-%{+YYYY.MM.dd}"
            hosts => ["node-1:9991","node-2:9991","node-3:9991"]
        }
    }
    

启动命令  bin/logstash -r -f /usr/logstash/logstash.conf

-r 表示配置文件修改自动重启

-f指定配置文件，多个配置文件使用通配符 bin/logstash -f '/tmp/{one,two,three}'

-f one ,-f two 直接指定多个只对最后后一个生效

 

三、Filebeat安装使用

1、下载Filebeat

wget https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-5.6.10-linux-x86_64.tar.gz

2、解压

       tar -zxvf filebeat-5.6.10-linux-x86_64.tar.gz

3、修改配置文件

5.x使用

    filebeat.prospectors:
    - type: log
      enabled: true
      paths:
      - /data/applog/*.log
      fields:
        project_name: ${PROJECT_NAME_REPLACE}
      fields_under_root: true
    output.logstash:
      hosts: ["logstash:5044"]
    

6.x使用

    filebeat.inputs:
    - type: log
      enabled: true
      paths:
        - /data/applog/*.log
      fields:
        project_name: ${PROJECT_NAME_REPLACE}
      fields_under_root: true
    output.logstash:
      hosts: ["logstash-1:5044"]
    



4、启动

./filebeat -e -c filebeat.yml

5、部署方式

       与每个应用一起部署，指定日志文件paths

四、kibnan安装使用

1、下载kibnan

wget https://artifacts.elastic.co/downloads/kibana/kibana-5.6.10-linux-x86_64.tar.gz

2、解压

tar -zxvf kibana-5.6.10-linux-x86_64.tar.gz

3、修改配置文件

vi kibana.yml

    server.port: 5601
    elasticsearch.url: http://node-1:9200
    elasticsearch.username: "admin"
    elasticsearch.password: "123456"
    



4、启动kibnan

cd kibana-5.6.10-linux-x86_64

./bin/kibnan

 

五、supervisord安装使用

1、安装

yum install python-setuptools

easy_install supervisor

2、使用

       生成配置文件：

echo_supervisord_conf > /etc/supervisord.conf

 

主配置：启动时指定

    
    
    ;配置http服务监听的 socket，它的作用是为了让supervisorctl 能连接supervisord  http server获取进程状态信息，包括管理子进程。
    [unix_http_server]
    file=/tmp/supervisor.sock   ; the path to the socket file
    ;chmod=0700                 ; socket file mode (default 0700)
    ;chown=nobody:nogroup       ; socket file uid:gid owner
    ;username=user              ; default is no username (open server)
    ;password=123               ; default is no password (open server)
    
    
    [rpcinterface:supervisor]
    supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface
    
    ;Supervisor提供了一个WebUI的管理界面，如果需要打开的话，就在这个配置段设置，port指定监听ip和端口，username 和password指定访问WebUI需要的认证信息
    [inet_http_server]
    port=*:9001        ; ip_address:port specifier, *:port for all iface
    username=admin              ; default is no username (open server)
    password=admin@123		      ; default is no password (open server)
    
    ;Supervisor服务的配置项，包括了logfile，logfile_maxbytes等等
    [supervisord]
    logfile=/tmp/supervisord.log ; main log file; default $CWD/supervisord.log
    logfile_maxbytes=50MB        ; max main logfile bytes b4 rotation; default 50MB
    logfile_backups=10           ; # of main logfile backups; 0 means none, default 10
    loglevel=info                ; log level; default info; others: debug,warn,trace
    pidfile=/tmp/supervisord.pid ; supervisord pidfile; default supervisord.pid
    nodaemon=false               ; 从前台启动设置为 true; default false
    minfds=1024                  ; min. avail startup file descriptors; default 1024
    minprocs=200                 ; min. avail process descriptors;default 200
    ;umask=022                   ; process file creation umask; default 022
    ;user=chrism                 ; default is current user, required if root
    ;identifier=supervisor       ; supervisord identifier, default is 'supervisor'
    ;directory=/tmp              ; default is not to cd during start
    ;nocleanup=true              ; don't clean up tempfiles at start; default false
    ;childlogdir=/tmp            ; 'AUTO' child log dir, default $TEMP
    ;environment=KEY="value"     ; key value pairs to add to environment
    ;strip_ansi=false            ; strip ansi escape codes in logs; def. false
    
    
    ;Supervisor的客户端程序supervisorctl的相关配置，注意serverurl对应的sock就是[unix_http_server]中file的配置项，如果上面配置了用户名密码，此处也需要配置
    [supervisorctl]
    serverurl=unix:///tmp/supervisor.sock  ; use a unix:// URL  for a unix socket
    ;serverurl=http://192.168.0.129:9001     ; use an http:// url to specify an inet socket
    ;username=qintao              ; should be same as in [*_http_server] if set
    ;password=123023                ; should be same as in [*_http_server] if set
    ;prompt=mysupervisor         ; cmd line prompt (default "supervisor")
    ;history_file=~/.sc_history  ; use readline history if available
    
    
    ;具体需要监控的程序配置项，通常不会直接定义在这里
    ;[program:theprogramname]
    ;command=/bin/cat              ; the program (relative uses PATH, can take args)
    ;process_name=%(program_name)s ; process_name expr (default %(program_name)s) 进程名称
    ;numprocs=1                    ; number of processes copies to start (def 1)  当
    ;directory=/tmp                ; directory to cwd to before exec (def no cwd)  如何command命令使用相对路径，需要定义命令路径
    ;umask=022                     ; umask for process (default None)
    ;priority=999                  ; the relative start priority (default 999)  进程优先权，数字越小优先级越高，高优先级的进程后启动，先关闭
    ;autostart=true                ; start at supervisord start (default: true)  定义启动Supervisor的时候是否启动该进程
    ;startsecs=1                   ; # of secs prog must stay up to be running (def. 1)  指定程序多少秒之后，判断启动成功，状态为success
    ;startretries=3                ; max # of serial start failures when starting (default 3) 启动尝试次数
    ;autorestart=unexpected        ; when to restart if exited after running (def: unexpected)  false：重启时进程不重启；unexpected：重启时，检查进程的exitcodes，仅当检查到时重启 ；true：重启时，直接重启进程
    ;exitcodes=0,2                 ; 'expected' exit codes used with autorestart (default 0,2) 与autorestart=unexpected配合使用
    ;stopsignal=QUIT               ; signal used to kill process (default TERM)  结束进程的方式
    ;stopwaitsecs=10               ; max num secs to wait b4 SIGKILL (default 10) 与startsecs意思相近
    ;stopasgroup=false             ; send stop signal to the UNIX process group (default false)
    ;killasgroup=false             ; SIGKILL the UNIX process group (def false)
    ;user=chrism                   ; setuid to this UNIX account to run the program  执行用户
    ;redirect_stderr=true          ; redirect proc stderr to stdout (default false)
    ;stdout_logfile=/a/path        ; stdout log path, NONE for none; default AUTO
    ;stdout_logfile_maxbytes=1MB   ; max # logfile bytes b4 rotation (default 50MB)
    ;stdout_logfile_backups=10     ; # of stdout logfile backups (0 means none, default 10)
    ;stdout_capture_maxbytes=1MB   ; number of bytes in 'capturemode' (default 0)
    ;stdout_events_enabled=false   ; emit events on stdout writes (default false)
    ;stderr_logfile=/a/path        ; stderr log path, NONE for none; default AUTO
    ;stderr_logfile_maxbytes=1MB   ; max # logfile bytes b4 rotation (default 50MB)
    ;stderr_logfile_backups=10     ; # of stderr logfile backups (0 means none, default 10)
    ;stderr_capture_maxbytes=1MB   ; number of bytes in 'capturemode' (default 0)
    ;stderr_events_enabled=false   ; emit events on stderr writes (default false)
    ;environment=A="1",B="2"       ; process environment additions (def no adds)
    ;serverurl=AUTO                ; override serverurl computation (childutils)  配置supervisorctl通信的url
    
    
    ;指定包含的配置文件的路径，通常被监控的程序配置文件，会放在这个路径下，一个程序一个，比较清楚。
    [include]
    files = /usr/conf/*.conf  ;在此目录下创建应用各自的program配置文件
    

               

 

为需要启动管理项目单独配置文件：

filebeat:

    [program:tomcat]
    command=/usr/tomcat/tomcat/bin/catalina.sh run
    stdout_logfile=/usr/tomcat/tomcat/logs/catalina.out
    autostart=true
    autorestart=true
    startsecs=5
    priority=2
    stopasgroup=true
    killasgroup=true
    

 

tomcat:  

    [program:tomcat]
    command=/usr/tomcat/tomcat/bin/catalina.sh run
    stdout_logfile=/usr/tomcat/tomcat/logs/catalina.out
    autostart=true
    autorestart=true
    startsecs=5
    priority=2
    stopasgroup=true
    killasgroup=true
    

 

3、启动 

 supervisord -n -c /etc/supervisord.conf

-n:前台启动

-c指定配置文件

4、查看运行状态

启动supervisord客户端，进入交互界面，

supervisorctl -c /etc/supervisord.conf

 

5、supervisor高可用测试

高可用架构：

方式一：使用supervisor管理另外两个supervisor 



方式二：在swarm环境下docker监控supervisord使用supervisord监控应用，当supervisord挂掉后swarm集群会自动启动docker启动supervisord

方式三：直接用crontab去守护supervisor



 

 

---





附注：

kill -1 //终端挂起或控制进程终止。当用户退出Shell时，由该进程启动的所有进程都会收到这个信号，默认动作为终止进程。

kill -2 //键盘中断。当用户按下组合键时，用户终端向正在运行中的由该终端启动的程序发出此信号。默认动作为终止进程。

kill -3 //键盘退出键被按下。当用户按下或组合键时，用户终端向正在运行中的由该终端启动的程序发出此信号。默认动作为退出程序。

kill -8 //发生致命的运算错误时发出。不仅包括浮点运算错误，还包括溢出及除数为0等所有的算法错误。默认动作为终止进程并产生core文件。

kill -9 //无条件终止进程。进程接收到该信号会立即终止，不进行清理和暂存工作。该信号不能被忽略、处理和阻塞，它向系统管理员提供了可以杀死任何进程的方法。

kill -14 //定时器超时，默认动作为终止进程。

kill -15 //程序结束信号，可以由 kill 命令产生。与SIGKILL不同的是，SIGTERM 信号可以被阻塞和终止，以便程序在退出前可以保存工作或清理临时文件等。


