title: 桥接模式-Bridge
date: '2019-11-11 16:44:54'
updated: '2019-11-11 16:52:00'
tags: [设计模式]
permalink: /articles/2019/11/11/1573461894480.html
---
# 桥接模式-Bridge

### 什么是桥接模式？

桥接（Bridge）是用于把抽象化与实现化解耦，使得二者可以独立变化。这种类型的设计模式属于结构型模式，它通过提供抽象化和实现化之间的桥接结构，来实现二者的解耦。

### 场景

1. 如果一个系统需要在构件的抽象化角色和具体化角色之间增加更多的灵活性，避免在两个层次之间建立静态的继承联系，通过桥接模式可以使它们在抽象层建立一个关联关系。
    
2. 对于那些不希望使用继承或因为多层次继承导致系统类的个数急剧增加的系统，桥接模式尤为适用。
    
3. 一个类存在两个独立变化的维度，且这两个维度都需要进行扩展。
    

### 示例

类的功能层次
```
public class Display {  
 private DisplayImpl display;  
​  
 public Display(DisplayImpl display) {  
 this.display = display;  
 }  
​  
 public void open() {  
 display.rawOpen();  
 }  
​  
 public void print() {  
 display.rawPrint();  
 }  
​  
 public void close() {  
 display.rawClose();  
​  
 }  
​  
​  
 public final void display() {  
 open();  
 print();  
 close();  
 }  
​  
}
```

```
public class CountDisplay extends Display {  
 public CountDisplay(DisplayImpl display) {  
 super(display);  
 }  
​  
 public void multDisplay(int times) {  
 open();  
 for (int i = 0; i < times; i++) {  
 print();  
 }  
​  
 close();  
​  
 }  
}
```

类的实现层次：

```
public abstract class DisplayImpl {  
​  
 public abstract void rawOpen();  
​  
 public abstract void rawPrint();  
​  
 public abstract void rawClose();  
​  
​  
}
```

```
public class StringDisplayImpl extends DisplayImpl {  
 private String string;  
​  
 private int width;  
​  
 public StringDisplayImpl(String string) {  
 this.string = string;  
 this.width = string.getBytes().length;  
 }  
​  
 @Override  
 public void rawOpen() {  
 printLine();  
 }  
​  
 @Override  
 public void rawPrint() {  
 System.out.println("|" + string + "|");  
 }  
​  
 @Override  
 public void rawClose() {  
 printLine();  
 }  
​  
 private void printLine() {  
 System.out.print("+");  
 for (int i = 0; i < width; i++) {  
 System.out.print("-");  
 }  
 System.out.println("+");  
 }  
}
```

测试类：

```
public class BridgeTest {  
​  
 public static void main(String[] args) {  
 Display display = new Display(new StringDisplayImpl("hello,word"));  
 Display display1 = new CountDisplay(new StringDisplayImpl("hello,count"));  
 Display display2 = new CountDisplay(new StringDisplayImpl("hello,count111"));  
 display.display();  
 display1.display();  
 display2.display();  
 ((CountDisplay) display2).multDisplay(5);  
 }  
}
```

### 典型应用：

JDK提供的JDBC数据库访问接口API正是经典的桥接模式的实现者，接口内部可以通过实现接口来扩展针对不同数据库的具体实现来进行扩展，而对外的仅仅只是一个统一的接口调用，调用方过于抽象，可以将其看做每一个JDBC调用程序.

### 继承还是委托

继承虽然很容易扩展，但是类之间会产生一种强关联关系，如果想轻松改变类之间的关系就不能使用继承，否则每次改变类都需要改变类之间的关系，在上面示例中使用委托，Display类的impl字段保存了实现的示例，这样类的任务就发生了转移。也就是说，其他类要求Display工作时并非自己工作，而是交给impl。
