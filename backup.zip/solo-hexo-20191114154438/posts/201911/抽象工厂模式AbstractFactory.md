title: 抽象工厂模式-Abstract Factory
date: '2019-11-11 15:33:46'
updated: '2019-11-11 15:42:25'
tags: [设计模式]
permalink: /articles/2019/11/11/1573457626709.html
---
![](https://img.hacpai.com/bing/20180604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 抽象工厂模式-Abstract Factory

### 什么是抽象工厂模式？

围绕一个超级工厂创建其他工厂。该超级工厂又称为其他工厂的工厂。这种类型的设计模式属于创建型模式，它提供了一种创建对象的最佳方式。在抽象工厂模式中，接口是负责创建一个相关对象的工厂，不需要显式指定它们的类。每个生成的工厂都能按照工厂模式提供对象。

### 场景：

工作了，为了参加一些聚会，肯定有两套或多套衣服吧，比如说有商务装（成套，一系列具体产品）、时尚装（成套，一系列具体产品），甚至对于一个家庭来说，可能有商务女装、商务男装、时尚女装、时尚男装，这些也都是成套的，即一系列具体产品。假设一种情况（现实中是不存在的，要不然，没法进入共产主义了，但有利于说明抽象工厂模式），在您的家中，某一个衣柜（具体工厂）只能存放某一种这样的衣服（成套，一系列具体产品），每次拿这种成套的衣服时也自然要从这个衣柜中取出了。用 OOP 的思想去理解，所有的衣柜（具体工厂）都是衣柜类的（抽象工厂）某一个，而每一件成套的衣服又包括具体的上衣（某一具体产品），裤子（某一具体产品），这些具体的上衣其实也都是上衣（抽象产品），具体的裤子也都是裤子（另一个抽象产品）。

### 角色

在抽象工厂模式包含如下几个角色：

* AbstractFactory（抽象工厂）：它声明了一组用于创建一族产品的方法，每一个方法对应一种产品。
    
* ConcreteFactory（具体工厂）：它实现了在抽象工厂中声明的创建产品的方法，生成一组具体产品，这些产品构成了一个产品族，每一个产品都位于某个产品等级结构中。
    
* AbstractProduct（抽象产品）：它为每种产品声明接口，在抽象产品中声明了产品所具有的业务方法
    
* ConcreteProduct（具体产品）：它定义具体工厂生产的具体产品对象，实现抽象产品接口中声明的业务方法。
    

### 示例

![æ½è±¡å·¥åæ¨¡å¼ç UML å¾](https://www.runoob.com/wp-content/uploads/2014/08/abstractfactory_pattern_uml_diagram.jpg)

为形状创建一个接口：
```
public interface Shape {  
 void draw();  
}
```

创建实现接口的实体类 :
```
public class Rectangle implements Shape {  
    
 @Override  
 public void draw() {  
 System.out.println("Inside Rectangle::draw() method.");  
 }  
}
```


```
public class Square implements Shape {  
    
 @Override  
 public void draw() {  
 System.out.println("Inside Square::draw() method.");  
 }  
}
```

```
public class Circle implements Shape {  
    
 @Override  
 public void draw() {  
 System.out.println("Inside Circle::draw() method.");  
 }  
}
```

为颜色创建一个接口:

```
public interface Color {  
 void fill();  
}
``` 

```
public class Red implements Color {  
    
 @Override  
 public void fill() {  
 System.out.println("Inside Red::fill() method.");  
 }  
}
```

```
public class Green implements Color {  
    
 @Override  
 public void fill() {  
 System.out.println("Inside Green::fill() method.");  
 }  
}
```

```
public class Blue implements Color {  
    
 @Override  
 public void fill() {  
 System.out.println("Inside Blue::fill() method.");  
 }  
}
```

为 Color 和 Shape 对象创建抽象类来获取工厂 :

```
public abstract class AbstractFactory {  
 public abstract Color getColor(String color);  
 public abstract Shape getShape(String shape) ;  
}
```

创建扩展了 AbstractFactory 的工厂类，基于给定的信息生成实体类的对象 :

```
public class ShapeFactory extends AbstractFactory {  
​  
 @Override  
 public Shape getShape(String shapeType) {  
 if (shapeType == null) {  
 return null;  
 }  
 try {  
 return (Shape) Class.forName(shapeType).newInstance();  
 } catch (Exception e) {  
 e.printStackTrace();  
 }  
 return null;  
 }  
​  
 @Override  
 public Color getColor(String color) {  
 return null;  
 }  
}
```

```
public class ColorFactory extends AbstractFactory {  
​  
 @Override  
 public Shape getShape(String shapeType) {  
 return null;  
 }  
​  
 @Override  
 public Color getColor(String color) {  
 if (color == null) {  
 return null;  
 }  
 try {  
 return (Color) Class.forName(color).newInstance();  
 } catch (Exception e) {  
 e.printStackTrace();  
 }  
 return null;  
 }  
}
```

创建一个工厂创造器/生成器类，通过传递形状或颜色信息来获取工厂 :

```
public class FactoryProducer {  
 public static AbstractFactory getFactory(String choice){  
 if(choice.equalsIgnoreCase("SHAPE")){  
 return new ShapeFactory();  
 } else if(choice.equalsIgnoreCase("COLOR")){  
 return new ColorFactory();  
 }  
 return null;  
 }  
}
```

测试类：

```
public class AbstractFactoryPatternDemo {  
 public static void main(String[] args) {  
​  
​  
 //获取形状工厂  
 AbstractFactory shapeFactory = FactoryProducer.getFactory("SHAPE");  
    
 //获取形状为 Circle 的对象  
 Shape shape1 = shapeFactory.getShape("online.taoqin.abstractfactory.Circle");  
    
 //调用 Circle 的 draw 方法  
 shape1.draw();  
    
 //获取形状为 Rectangle 的对象  
 Shape shape2 = shapeFactory.getShape("online.taoqin.abstractfactory.Rectangle");  
    
 //调用 Rectangle 的 draw 方法  
 shape2.draw();  
   
 //获取形状为 Square 的对象  
 Shape shape3 = shapeFactory.getShape("online.taoqin.abstractfactory.Square");  
    
 //调用 Square 的 draw 方法  
 shape3.draw();  
    
 //获取颜色工厂  
 AbstractFactory colorFactory = FactoryProducer.getFactory("COLOR");  
    
 //获取颜色为 Red 的对象  
 Color color1 = colorFactory.getColor("online.taoqin.abstractfactory.Red");  
    
 //调用 Red 的 fill 方法  
 color1.fill();  
    
 //获取颜色为 Green 的对象  
 Color color2 = colorFactory.getColor("online.taoqin.abstractfactory.Green");  
    
 //调用 Green 的 fill 方法  
 color2.fill();  
    
 //获取颜色为 Blue 的对象  
 Color color3 = colorFactory.getColor("online.taoqin.abstractfactory.Blue");  
    
 //调用 Blue 的 fill 方法  
 color3.fill();  
 }  
}
```

### 典型场景：

在Spring中，工厂的例子是org.springframework.beans.factory.BeanFactory。通过它的实现，我们可以从Spring的容器访问bean。根据采用的策略，getBean方法可以返回已创建的对象（共享实例，单例作用域）或初始化新的对象（原型作用域）。在BeanFactory的实现中，我们可以区分：ClassPathXmlApplicationContext，XmlWebApplicationContext，StaticWebApplicationContext，StaticPortletApplicationContext，GenericApplicationContext，StaticApplicationContext。

### 延伸阅读：各种生成实例的方法的介绍

* new关键字
    

* clone模式，使用原型模式进行实例的创建
    

* 使用newInstance创建，或者使用已经存在实例创建实例
    
```
ColorFactory abstractFactory = new ColorFactory();  
ColorFactory colorFactory = abstractFactory.getClass().newInstance();
```

