title: 原型模式-Prototype
date: '2019-11-11 10:39:12'
updated: '2019-11-11 10:40:43'
tags: [设计模式]
permalink: /articles/2019/11/11/1573439952938.html
---
# 原型模式-Prototype

### 什么是原型模式？

使用原型实例指定创建对象的种类，并且通过拷贝这些原型创建新的对象。原型模式是一种对象创建型模式。

### 场景：

将输入的字符串加上下划线或者方框，通过使用已经创建的实例创建需要添加下划线的实例或者加上方框的实例

### 测试
声明功能方法的接口：
```
/**  
 * 复制功能的接口  
 */  
public interface Product extends Cloneable {  
​  
 public abstract void use(String s);  
​  
 public abstract Product createClone();  
}
```

复制实例的类：
```
public class Manager {  
​  
 private Map showcase = new HashMap();  
​  
 public void register(String name,Product product){  
 showcase.put(name,product);  
 }  
​  
 public Product create(String protoname){  
 Product p = (Product) showcase.get(protoname);  
 return p.createClone();  
 }  
}
```
将字符串放入方框中并且显示的类：
```
public class MessageBox implements Product {  
 private char decochar;  
​  
 public MessageBox(char decochar) {  
 this.decochar = decochar;  
 }  
​  
 @Override  
 public void use(String s) {  
 int length = s.length();  
 for (int i = 0; i < length + 4; i++) {  
 System.out.print(decochar);  
 }  
 System.out.println("");  
 System.out.println(decochar + " " + s + " " + decochar);  
 for (int i = 0; i < length + 4; i++) {  
 System.out.print(decochar);  
 }  
 System.out.println("");  
 }  
​  
 @Override  
 public Product createClone() {  
 try {  
 Product clone = (Product) clone();  
 return clone;  
 } catch (CloneNotSupportedException e) {  
 e.printStackTrace();  
 }  
 return null;  
 }  
}
```
```
public class UnderlinePen implements Product {  
​  
 private char decochar;  
​  
 public UnderlinePen(char decochar) {  
 this.decochar = decochar;  
 }  
​  
 @Override  
 public void use(String s) {  
 int length = s.length();  
 System.out.println("\"" + s + "\"");  
 System.out.print(" ");  
 for (int i = 0; i < length; i++) {  
 System.out.print(decochar);  
 }  
 System.out.println("");  
 }  
​  
 @Override  
 public Product createClone() {  
 try {  
​  
 Product clone = (Product) clone();  
 return clone;  
 } catch (CloneNotSupportedException e) {  
 e.printStackTrace();  
 }  
 return null;  
 }  
}
```


测试类：
```
public class PrototypeTest {  
​  
 public static void main(String[] args) {  
​  
 Manager manager = new Manager();  
 UnderlinePen underlinePen = new UnderlinePen('~');  
 MessageBox messageBox = new MessageBox('*');  
 MessageBox messageBox1 = new MessageBox('/');  
 manager.register("strong message",underlinePen);  
 manager.register("warning box",messageBox);  
 manager.register("slash box",messageBox1);  
​  
 for (int i = 0; i < 100; i++) {  
 Product strong_message = manager.create("strong message");  
 strong_message.use("hello ,word");  
 System.out.println(""+strong_message);  
 }  
 Product warning_box = manager.create("warning box");  
 warning_box.use("hello ,word");  
 Product slash_box = manager.create("slash box");  
 slash_box.use("hello ,word");  
​  
 }  
}
```

原型模式的核心在于如何实现clone方法

### java中的clone

#### 浅克隆

被复制对象的所有变量都含有与原来的对象相同的值，而所有的对其他对象的引用仍然指向原来的对象。换言之，浅复制仅仅复制所拷贝的对象，而不复制它所引用的对象。

#### 深克隆

被复制对象的所有变量都含有与原来的对象相同的值，除去那些引用其他对象的变量。那些引用其他对象的变量将指向被复制过的新对象，而不再是原有的那些被引用的对象。换言之，深复制把要复制的对象所引用的对象都复制了一遍。

深克隆方法：
```
// 深克隆  
 public Object deepClone() throws IOException, ClassNotFoundException {  
 // 序列化  
 ByteArrayOutputStream bos = new ByteArrayOutputStream();  
 ObjectOutputStream oos = new ObjectOutputStream(bos);  
 oos.writeObject(this);  
 // 反序列化  
 ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());  
 ObjectInputStream ois = new ObjectInputStream(bis);  
 return ois.readObject();  
 }  
//或者使用  
SerializationUtils.clone(T object);
```

