title: 策略模式-Strategy
date: '2019-11-12 15:07:12'
updated: '2019-11-12 15:08:47'
tags: [设计模式]
permalink: /articles/2019/11/12/1573542432382.html
---
![](https://img.hacpai.com/bing/20171105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 策略模式-Strategy

### 什么是策略模式？

在软件开发中，无论什么程序，目的都是解决问题，为了解决问题又需要编写特定的算法，策略模式可以整体的替换算法的实现部分。

### 使用场景：

在有多种算法相似的情况下，使用 if...else 所带来的复杂和难以维护

### 角色

* Context（环境类）：环境类是使用算法的角色，它在解决某个问题（即实现某个方法）时可以采用多种策略。在环境类中维持一个对抽象策略类的引用实例，用于定义所采用的策略。
    

* Strategy（抽象策略类）：它为所支持的算法声明了抽象方法，是所有策略类的父类，它可以是抽象类或具体类，也可以是接口。环境类通过抽象策略类中声明的方法在运行时调用具体策略类中实现的算法。
    
* ConcreteStrategy（具体策略类）：它实现了在抽象策略类中声明的算法，在运行时，具体策略类将覆盖在环境类中定义的抽象策略类对象，使用一种具体的算法实现某个业务处理。
    

### 示例：

策略接口：

```
public interface Strategy {  
 public int doOperation(int num1, int num2);  
}
```

策略实现类：

```
public class OperationAdd implements Strategy{  
 @Override  
 public int doOperation(int num1, int num2) {  
 return num1 + num2;  
 }  
}
```

```
public class OperationMultiply implements Strategy{  
 @Override  
 public int doOperation(int num1, int num2) {  
 return num1 * num2;  
 }  
}
```

```
public class OperationSubstract implements Strategy{  
 @Override  
 public int doOperation(int num1, int num2) {  
 return num1 - num2;  
 }  
}
```

调用类：

```
public class Context {  
 private Strategy strategy;  
    
 public Context(){  
   
 }  
​  
 public void setStrategy(Strategy strategy){  
 this.strategy = strategy;  
 }  
​  
 public int executeStrategy(int num1, int num2){  
 return strategy.doOperation(num1, num2);  
 }  
}
```

测试类：

```
public class StrategyPatternDemo {  
 public static void main(String[] args) {  
 Context context = new Context();  
 context.setStrategy(new OperationAdd());  
 System.out.println("10 + 5 = " + context.executeStrategy(10, 5));  
 context.setStrategy(new OperationSubstract());  
 System.out.println("10 - 5 = " + context.executeStrategy(10, 5));  
 context.setStrategy(new OperationMultiply());  
 System.out.println("10 * 5 = " + context.executeStrategy(10, 5));  
 }  
}
```

### 典型场景

在Spring中，实例化对象的时候用到了Strategy模式，图示如下所示：
![63420220190705171201968174571388.png](https://img.hacpai.com/file/2019/11/63420220190705171201968174571388-c44ac685.png)

在上图中：InstantiationStrategy为抽象接口，SimpleInstantiationStrategy实现接口，但是在方法instantiate中进行判断，针对bd中没有MethodOverrides的，直接通过jdk反射进行构造函数调用，而针对有需要针对方法做MethodOverrides的，则可以通过另一种方式处理，在SimpleInstantiationStrategy中是通过：instantiateWithMethodInjection()方法处理的，在CglibSubclassingInstantiationStrategy中对该方法做了override实现。CglibSubclassingInstantiationStrategy继承自SimpleInstantiationStrategy，对MethodInjection方法的实现如下：

```
@Override  
protected Object instantiateWithMethodInjection(RootBeanDefinition bd, @Nullable String beanName, BeanFactory owner,@Nullable Constructor<?> ctor, Object... args) {  
​  
 // Must generate CGLIB subclass...  
 return new CglibSubclassCreator(bd, owner).instantiate(ctor, args);  
​  
}
```

通过static的class类CglibSubclassCreator进行instantiate操作，剩下的就是cglib内中的细节了，此处不分析。

策略模式中包含的部分是：

1. 抽象策略InstantiationStrategy接口
    
2. 具体策略SimpleInstantiationStrategy，被继承后子类CglibSubclassingInstantiationStrategy，实现自抽象策略接口
    
3. 上下文对策略的引用，在AbstractAutowireCapableBeanFactory中是通过new CglibSubclassingInstantiationStrategy赋值给InstantiationStrateg的引用，进而进行具体的方法调用，具体见下方代码：
    

```
public abstract class AbstractAutowireCapableBeanFactory extends AbstractBeanFactory  
 implements AutowireCapableBeanFactory {  
​  
 private InstantiationStrategy instantiationStrategy = new CglibSubclassingInstantiationStrategy();  
}
```
