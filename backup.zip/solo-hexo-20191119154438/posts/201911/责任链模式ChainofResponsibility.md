title: 责任链模式-Chain of Responsibility
date: '2019-11-14 18:04:19'
updated: '2019-11-14 18:04:31'
tags: [设计模式]
permalink: /articles/2019/11/14/1573725859564.html
---
![](https://img.hacpai.com/bing/20180111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 责任链模式-Chain of Responsibility

### 什么是责任链模式

为请求创建了一个接收者对象的链。这种模式给予请求的类型，对请求的发送者和接收者进行解耦。这种类型的设计模式属于行为型模式。

在这种模式中，通常每个接收者都包含对另一个接收者的引用。如果一个对象不能处理该请求，那么它会把相同的请求传给下一个接收者，依此类推。

### 角色

- Handler（抽象处理者）：它定义了一个处理请求的接口，一般设计为抽象类，由于不同的具体处理者处理请求的方式不同，因此在其中定义了抽象请求处理方法。因为每一个处理者的下家还是一个处理者，因此在抽象处理者中定义了一个抽象处理者类型的对象，作为其对下家的引用。通过该引用，处理者可以连成一条链。

- ConcreteHandler（具体处理者）：它是抽象处理者的子类，可以处理用户请求，在具体处理者类中实现了抽象处理者中定义的抽象请求处理方法，在处理请求之前需要进行判断，看是否有相应的处理权限，如果可以处理请求就处理它，否则将请求转发给后继者；在具体处理者中可以访问链中下一个对象，以便请求的转发。



### 示例

发生问题的类

    public class Trouble {
    
        private int number;
    
        public Trouble(int number) {
            this.number = number;
        }
    
        @Override
        public String toString() {
            return "Trouble{" +
                    "number=" + number +
                    '}';
        }
    
        public int getNumber() {
            return number;
        }
    }

解决问题抽象类

    public abstract class Support {
    
        private String name;
    
        private Support next;
    
        public Support(String name) {
            this.name = name;
        }
    
        public Support setNext(Support support) {
            this.next = support;
            return support;
        }
    
        public final void suppot(Trouble trouble) {
    
            if (resolve(trouble)) {
                done(trouble);
            } else if (next != null) {
                next.suppot(trouble);
            } else {
                fail(trouble);
            }
        }
    
        protected abstract boolean resolve(Trouble trouble);
    
        protected void done(Trouble trouble) {
            System.out.println(trouble + "is resolved by " + this + ".");
        }
    
        protected void fail(Trouble trouble) {
            System.out.println(trouble + "cannot be resolved.");
        }
    
    }

解决问题实现类

    public class NoSuppot extends Support {
    
        public NoSuppot(String name) {
            super(name);
        }
    
        @Override
        protected boolean resolve(Trouble trouble) {
            return false;
        }
    }

    public class LimitSuppot extends Support {
    
        private int limit;
    
        public LimitSuppot(String name, int limit) {
            super(name);
            this.limit = limit;
        }
    
        @Override
        protected boolean resolve(Trouble trouble) {
            if (trouble.getNumber() < limit){
                return true;
            }
            return false;
        }
    }

    public class OddSuppot extends Support {
    
        public OddSuppot(String name) {
            super(name);
        }
    
        @Override
        protected boolean resolve(Trouble trouble) {
            if (trouble.getNumber() % 2 == 1){
                return true;
            }
            return false;
        }
    }

    public class SpecialSuppot extends Support {
        private int number;
    
        public SpecialSuppot(String name, int number) {
            super(name);
            this.number = number;
        }
    
        @Override
        protected boolean resolve(Trouble trouble) {
            if (trouble.getNumber() == number){
                return true;
            }
            return false;
        }
    }

测试类

    public class ChainOfResponsibility {
        public static void main(String[] args) {
            Support alice = new NoSuppot("Alice");
            Support bob = new LimitSuppot("Bob",100);
            Support charlie = new SpecialSuppot("Charlie",429);
            Support diana = new LimitSuppot("Diana",200);
            Support elmo = new OddSuppot("Elmo");
            Support fred = new LimitSuppot("Fred",300);
            alice.setNext(bob).setNext(charlie).setNext(diana).setNext(elmo).setNext(fred);
            for (int i = 0; i < 500; i++) {
                alice.suppot(new Trouble(i));
            }
        }
    }

### 责任链模式在Tomcat中的应用

　　众所周知Tomcat中的Filter就是使用了责任链模式，创建一个Filter除了要在web.xml文件中做相应配置外，还需要实现javax.servlet.Filter接口。

    public class TestFilter implements Filter{
     
        public void doFilter(ServletRequest request, ServletResponse response,
                FilterChain chain) throws IOException, ServletException {
            
            chain.doFilter(request, response);
        }
     
        public void destroy() {
        }
     
        public void init(FilterConfig filterConfig) throws ServletException {
        }
     
    }

使用DEBUG模式所看到的结果如下
![责任链1.png](https://img.hacpai.com/file/2019/11/责任链1-26d97af9.png)



　　其实在真正执行到TestFilter类之前，会经过很多Tomcat内部的类。顺带提一下其实Tomcat的容器设置也是责任链模式，注意被红色方框所圈中的类，从Engine到Host再到Context一直到Wrapper都是通过一个链传递请求。被绿色方框所圈中的地方有一个名为ApplicationFilterChain的类，ApplicationFilterChain类所扮演的就是抽象处理者角色，而具体处理者角色由各个Filter扮演。

　　第一个疑问是ApplicationFilterChain将所有的Filter存放在哪里？

　　答案是保存在ApplicationFilterChain类中的一个ApplicationFilterConfig对象的数组中。

    /**
         * Filters.
         */
        private ApplicationFilterConfig[] filters = new ApplicationFilterConfig[0];

那ApplicationFilterConfig对象又是什么呢？

　  ApplicationFilterConfig是一个Filter容器。以下是ApplicationFilterConfig类的声明：

    /**
     * Implementation of a <code>javax.servlet.FilterConfig</code> useful in
     * managing the filter instances instantiated when a web application
     * is first started.
     *
     * @author Craig R. McClanahan
     * @version $Id: ApplicationFilterConfig.java 1201569 2011-11-14 01:36:07Z kkolinko $
     */

当一个web应用首次启动时ApplicationFilterConfig会自动实例化，它会从该web应用的web.xml文件中读取配置的Filter的信息，然后装进该容器。

　　刚刚看到在ApplicationFilterChain类中所创建的ApplicationFilterConfig数组长度为零，那它是在什么时候被重新赋值的呢？

    private ApplicationFilterConfig[] filters =  ApplicationFilterConfig[0];

 是在调用ApplicationFilterChain类的addFilter()方法时。 

    /**
    * The int which gives the current number of filters in the chain.
    */
    private int n = 0;
    public static final int INCREMENT = 10;
    void addFilter(ApplicationFilterConfig filterConfig) {
     
            // Prevent the same filter being added multiple times
            for(ApplicationFilterConfig filter:filters)
                if(filter==filterConfig)
                    return;
     
            if (n == filters.length) {
                ApplicationFilterConfig[] newFilters =
                    new ApplicationFilterConfig[n + INCREMENT];
                System.arraycopy(filters, 0, newFilters, 0, n);
                filters = newFilters;
            }
            filters[n++] = filterConfig;
     
        }

变量n用来记录当前过滤器链里面拥有的过滤器数目，默认情况下n等于0，ApplicationFilterConfig对象数组的长度也等于0，所以当第一次调用addFilter()方法时，if (n == filters.length)的条件成立，ApplicationFilterConfig数组长度被改变。之后filters[n++] = filterConfig;将变量filterConfig放入ApplicationFilterConfig数组中并将当前过滤器链里面拥有的过滤器数目+1。

　　那ApplicationFilterChain的addFilter()方法又是在什么地方被调用的呢？

　　是在ApplicationFilterFactory类的createFilterChain()方法中。

    public ApplicationFilterChain createFilterChain
            (ServletRequest request, Wrapper wrapper, Servlet servlet) {
     
            // get the dispatcher type
            DispatcherType dispatcher = null; 
            if (request.getAttribute(DISPATCHER_TYPE_ATTR) != null) {
                dispatcher = (DispatcherType) request.getAttribute(DISPATCHER_TYPE_ATTR);
            }
            String requestPath = null;
            Object attribute = request.getAttribute(DISPATCHER_REQUEST_PATH_ATTR);
            
            if (attribute != null){
                requestPath = attribute.toString();
            }
            
            // If there is no servlet to execute, return null
            if (servlet == null)
                return (null);
     
            boolean comet = false;
            
            // Create and initialize a filter chain object
            ApplicationFilterChain filterChain = null;
            if (request instanceof Request) {
                Request req = (Request) request;
                comet = req.isComet();
                if (Globals.IS_SECURITY_ENABLED) {
                    // Security: Do not recycle
                    filterChain = new ApplicationFilterChain();
                    if (comet) {
                        req.setFilterChain(filterChain);
                    }
                } else {
                    filterChain = (ApplicationFilterChain) req.getFilterChain();
                    if (filterChain == null) {
                        filterChain = new ApplicationFilterChain();
                        req.setFilterChain(filterChain);
                    }
                }
            } else {
                // Request dispatcher in use
                filterChain = new ApplicationFilterChain();
            }
     
            filterChain.setServlet(servlet);
     
            filterChain.setSupport
                (((StandardWrapper)wrapper).getInstanceSupport());
     
            // Acquire the filter mappings for this Context
            StandardContext context = (StandardContext) wrapper.getParent();
            FilterMap filterMaps[] = context.findFilterMaps();
     
            // If there are no filter mappings, we are done
            if ((filterMaps == null) || (filterMaps.length == 0))
                return (filterChain);
     
            // Acquire the information we will need to match filter mappings
            String servletName = wrapper.getName();
     
            // Add the relevant path-mapped filters to this filter chain
            for (int i = 0; i < filterMaps.length; i++) {
                if (!matchDispatcher(filterMaps[i] ,dispatcher)) {
                    continue;
                }
                if (!matchFiltersURL(filterMaps[i], requestPath))
                    continue;
                ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)
                    context.findFilterConfig(filterMaps[i].getFilterName());
                if (filterConfig == null) {
                    // FIXME - log configuration problem
                    continue;
                }
                boolean isCometFilter = false;
                if (comet) {
                    try {
                        isCometFilter = filterConfig.getFilter() instanceof CometFilter;
                    } catch (Exception e) {
                        // Note: The try catch is there because getFilter has a lot of 
                        // declared exceptions. However, the filter is allocated much
                        // earlier
                        Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
                        ExceptionUtils.handleThrowable(t);
                    }
                    if (isCometFilter) {
                        filterChain.addFilter(filterConfig);
                    }
                } else {
                    filterChain.addFilter(filterConfig);
                }
            }
     
            // Add filters that match on servlet name second
            for (int i = 0; i < filterMaps.length; i++) {
                if (!matchDispatcher(filterMaps[i] ,dispatcher)) {
                    continue;
                }
                if (!matchFiltersServlet(filterMaps[i], servletName))
                    continue;
                ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)
                    context.findFilterConfig(filterMaps[i].getFilterName());
                if (filterConfig == null) {
                    // FIXME - log configuration problem
                    continue;
                }
                boolean isCometFilter = false;
                if (comet) {
                    try {
                        isCometFilter = filterConfig.getFilter() instanceof CometFilter;
                    } catch (Exception e) {
                        // Note: The try catch is there because getFilter has a lot of 
                        // declared exceptions. However, the filter is allocated much
                        // earlier
                    }
                    if (isCometFilter) {
                        filterChain.addFilter(filterConfig);
                    }
                } else {
                    filterChain.addFilter(filterConfig);
                }
            }
     
            // Return the completed filter chain
            return (filterChain);
     
        }

可以将如上代码分为两段，51行之前为第一段，51行之后为第二段。

　　第一段的主要目的是创建ApplicationFilterChain对象以及一些参数设置。

　　第二段的主要目的是从上下文中获取所有Filter信息，之后使用for循环遍历并调用filterChain.addFilter(filterConfig);将filterConfig放入ApplicationFilterChain对象的ApplicationFilterConfig数组中。

　　那ApplicationFilterFactory类的createFilterChain()方法又是在什么地方被调用的呢？

　　是在StandardWrapperValue类的invoke()方法中被调用的。

　　![责任链2.png](https://img.hacpai.com/file/2019/11/责任链2-1ac3a5ad.png)


　　由于invoke()方法较长，所以将很多地方省略。

    public final void invoke(Request request, Response response)
            throws IOException, ServletException {
       ...省略中间代码
    　　　　 // Create the filter chain for this request
            ApplicationFilterFactory factory =
                ApplicationFilterFactory.getInstance();
            ApplicationFilterChain filterChain =
                factory.createFilterChain(request, wrapper, servlet);
    　　...省略中间代码
             filterChain.doFilter(request.getRequest(), response.getResponse());
    　　...省略中间代码
        }

那正常的流程应该是这样的：

　　在StandardWrapperValue类的invoke()方法中调用ApplicationFilterChai类的createFilterChain()方法———>在ApplicationFilterChai类的createFilterChain()方法中调用ApplicationFilterChain类的addFilter()方法———>在ApplicationFilterChain类的addFilter()方法中给ApplicationFilterConfig数组赋值。

![责任链3.png](https://img.hacpai.com/file/2019/11/责任链3-1a57e877.png)


　　根据上面的代码可以看出StandardWrapperValue类的invoke()方法在执行完createFilterChain()方法后，会继续执行ApplicationFilterChain类的doFilter()方法，然后在doFilter()方法中会调用internalDoFilter()方法。

　　以下是internalDoFilter()方法的部分代码

    // Call the next filter if there is one
            if (pos < n) {
    　　　　　　　//拿到下一个Filter，将指针向下移动一位
                //pos它来标识当前ApplicationFilterChain（当前过滤器链）执行到哪个过滤器
                ApplicationFilterConfig filterConfig = filters[pos++];
                Filter filter = null;
                try {
    　　　　　　　　　 //获取当前指向的Filter的实例
                    filter = filterConfig.getFilter();
                    support.fireInstanceEvent(InstanceEvent.BEFORE_FILTER_EVENT,
                                              filter, request, response);
                    
                    if (request.isAsyncSupported() && "false".equalsIgnoreCase(
                            filterConfig.getFilterDef().getAsyncSupported())) {
                        request.setAttribute(Globals.ASYNC_SUPPORTED_ATTR,
                                Boolean.FALSE);
                    }
                    if( Globals.IS_SECURITY_ENABLED ) {
                        final ServletRequest req = request;
                        final ServletResponse res = response;
                        Principal principal = 
                            ((HttpServletRequest) req).getUserPrincipal();
     
                        Object[] args = new Object[]{req, res, this};
                        SecurityUtil.doAsPrivilege
                            ("doFilter", filter, classType, args, principal);
                        
                    } else {
    　　　　　　　　　　　　//调用Filter的doFilter()方法  
                        filter.doFilter(request, response, this);
                    }

这里的filter.doFilter(request, response, this);就是调用我们前面创建的TestFilter中的doFilter()方法。而TestFilter中的doFilter()方法会继续调用chain.doFilter(request, response);方法，而这个chain其实就是ApplicationFilterChain,所以调用过程又回到了上面调用dofilter和调用internalDoFilter方法，这样执行直到里面的过滤器全部执行。

　　如果定义两个过滤器，则Debug结果如下：
![责任链4.png](https://img.hacpai.com/file/2019/11/责任链4-031b9e24.png)



