title: 迭代器模式-Iterator
date: '2019-11-05 11:37:10'
updated: '2019-11-05 11:43:51'
tags: [设计模式]
permalink: /articles/2019/11/05/1572925030079.html
---
# 迭代器模式-Iterator

### 场景

数组进行遍历，传统模式使用for循环进行遍历操作具体值

```
int[] arr = {3,4,5,6};   
for (int i = 0; i < arr.length; i++) {   
 System.out.println(arr[i]);   
}
```

### 迭代器示例

使用数组模拟一个书架，存放书籍，并能遍历所有书籍。

迭代器接口
```
public interface Iterator {  
​  
 public abstract boolean hasNext();  
​  
 public abstract Object next();  
​  
}
```
定义获取iterator方法，该方法生成一个用于遍历集合的迭代器
```
public interface Aggregate {  
 public abstract Iterator iterator();  
}
```
Book类
```
public class Book {  
​  
 private String name;  
​  
 public String getName() {  
 return name;  
 }  
​  
 public void setName(String name) {  
 this.name = name;  
 }  
​  
 public Book(String name) {  
 this.name = name;  
 }  
}
```
书架类
```
public class BookShelf implements Aggregate {  
​  
 private Book[] books;  
​  
 private int last = 0;  
​  
 public BookShelf(int maxSize) {  
 this.books = new Book[maxSize];  
 }  
 public Book getBookAt(int index){  
 return books[index];  
 }  
 public void appendBook(Book book){  
 this.books[last] = book;  
 last++;  
 }  
​  
 public int getLength(){  
 return last;  
 }  
​  
 @Override  
 public Iterator iterator() {  
 return new BookShelfIterator(this);  
 }  
}
```
遍历书架类迭代器
```
public class BookShelfIterator implements Iterator{  
​  
 private BookShelf bookShelf;  
​  
 private int index;  
​  
 public BookShelfIterator(BookShelf bookShelf) {  
 this.bookShelf = bookShelf;  
 this.index = 0;  
 }  
​  
 @Override  
 public boolean hasNext() {  
 if (index < bookShelf.getLength()){  
 return true;  
 }  
 return false;  
 }  
​  
 @Override  
 public Object next() {  
 Book book = bookShelf.getBookAt(index);  
 index++;  
 return book;  
 }  
}
```
迭代器测试类
```
public class IteratorTest {  
​  
 public static void main(String[] args) {  
​  
 BookShelf bookShelf = new BookShelf(4);  
 bookShelf.appendBook(new Book("并发编程"));  
 bookShelf.appendBook(new Book("重构"));  
 bookShelf.appendBook(new Book("大话设计模式"));  
 bookShelf.appendBook(new Book("图解设计模式"));  
 Iterator iterator = bookShelf.iterator();  
 while (iterator.hasNext()){  
 Book next = (Book) iterator.next();  
 System.out.println(next.getName());  
 }  
 }  
}
```
**迭代器的优点，使用Iterator可以将遍历与实现分离，示例使用数组来实现，对于测试中具体遍历而言，无论修改书架使用数组还是集合等其他容器实现，对于遍历没有任何影响，如果使用传统for循环，只要存储容器发生变化，都会影响具体遍历实现。**

#### 抽象类与接口

平时如果只是用类解决问题，很容易导致类鱼类之间的强耦合，类也很难作为组件再次利用，为了弱化类之间的耦合，使类容易作为组件更容易复用，需要引入抽象类和接口。

不要使用具体类编程，优先使用抽象类和接口编程
