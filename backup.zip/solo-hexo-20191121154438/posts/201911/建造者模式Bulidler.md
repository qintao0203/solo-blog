title: 建造者模式-Bulidler
date: '2019-11-11 11:38:41'
updated: '2019-11-11 11:38:41'
tags: [设计模式]
permalink: /articles/2019/11/11/1573443521074.html
---
# 建造者模式-Bulidler

### 什么是建造者模式

 将一个复杂对象的构建与它的表示分离，使得同样的构建过程可以创建不同的表示。建造者模式是一种对象创建型模式。 

### 角色

Builder（抽象建造者）：它为创建一个产品Product对象的各个部件指定抽象接口，在该接口中一般声明两类方法，一类方法是buildPartX()，它们用于创建复杂对象的各个部件；另一类方法是getResult()，它们用于返回复杂对象。Builder既可以是抽象类，也可以是接口。

ConcreteBuilder（具体建造者）：它实现了Builder接口，实现各个部件的具体构造和装配方法，定义并明确它所创建的复杂对象，也可以提供一个方法返回创建好的复杂产品对象。

Product（产品角色）：它是被构建的复杂对象，包含多个组成部件，具体建造者创建该产品的内部表示并定义它的装配过程。

Director（指挥者）：指挥者又称为导演类，它负责安排复杂对象的建造次序，指挥者与抽象建造者之间存在关联关系，可以在其construct()建造方法中调用建造者对象的部件构造与装配方法，完成复杂对象的建造。客户端一般只需要与指挥者进行交互，在客户端确定具体建造者的类型，并实例化具体建造者对象（也可以通过配置文件和反射机制），然后通过指挥者类的构造函数或者Setter方法将该对象传入指挥者类中。

### 示例：

Builder类

    public abstract class Builder {
    
        public abstract void makeTitle(String title);
        public abstract void makeString(String str);
        public abstract void makeTItems(String[] items);
        public abstract void close();
    }

Director类

    public class Director {
        private Builder builder;
    
        public Director(Builder builder) {
            this.builder = builder;
        }
    
        public void construce(){
            builder.makeTitle("这是标题");
            builder.makeString("这是 内容");
            builder.makeTItems(new String[]{
                    "item1",
                    "item2"
            });
            builder.makeString("内容2");
            builder.makeTItems(new String[]{
                    "item3",
                    "item4"
            });
            builde
                r.close();
        }
    }



TextBuilder类：

    public class TextBuilder extends Builder{
    
        private StringBuffer buffer = new StringBuffer();
    
        @Override
        public void makeTitle(String title) {
         buffer.append("=====================================\n");
         buffer.append(title);
         buffer.append("\n");
        }
    
        @Override
        public void makeString(String str) {
            buffer.append("----------------------\n");
            buffer.append(str);
        }
    
        @Override
        public void makeTItems(String[] items) {
            for (int i = 0; i < items.length; i++) {
                buffer.append(items[i] + "\n");
            }
        }
    
        @Override
        public void close() {
            buffer.append("================close===================");
        }
        public String getResult(){
            return buffer.toString();
        }
    }

测试类：

    public class BuilderTest {
        public static void main(String[] args) {
            TextBuilder textBuilder = new TextBuilder();
            Director director = new Director(textBuilder);
            director.construce();
            String result = textBuilder.getResult();
            System.out.println(result);
        }
    }

### 典型应用

#### java.lang.StringBuilder 中的建造者模式

StringBuilder 的继承实现关系如下所示





Appendable 接口如下

    public interface Appendable {
        Appendable append(CharSequence csq) throws IOException;
    
        Appendable append(CharSequence csq, int start, int end) throws IOException;
    
        Appendable append(char c) throws IOException;
    }

StringBuilder 中的 append 方法使用了建造者模式，不过装配方法只有一个，并不算复杂，append 方法返回的是 StringBuilder 自身

    public final class StringBuilder extends AbstractStringBuilder implements java.io.Serializable, CharSequence {
        @Override
        public StringBuilder append(String str) {
            super.append(str);
            return this;
        }    // ...省略...// 
    }

StringBuilder 的父类 AbstractStringBuilder 实现了 Appendable 接口

    abstract class AbstractStringBuilder implements Appendable, CharSequence {
        char[] value;
        int count;
    
        public AbstractStringBuilder append(String str) {
            if (str == null)
                return appendNull();
            int len = str.length();
            ensureCapacityInternal(count + len);
            str.getChars(0, len, value, count);
            count += len;
            return this;
        }
    
        private void ensureCapacityInternal(int minimumCapacity) {
            // overflow-conscious code
            if (minimumCapacity - value.length > 0) {
                value = Arrays.copyOf(value,
                        newCapacity(minimumCapacity));
            }
        }
        // ...省略...
    }

我们可以看出，Appendable 为抽象建造者，定义了建造方法，StringBuilder 既充当指挥者角色，又充当产品角色，又充当具体建造者，建造方法的实现由 AbstractStringBuilder 完成，而 StringBuilder 继承了 AbstractStringBuilder

#### mybatis 中的建造者模式

 org.apache.ibatis.session 包下的 SqlSessionFactoryBuilder 类 里边很多重载的 build 方法，返回值都是 SqlSessionFactory，除了最后两个所有的 build最后都调用下面这个 build 方法 

       public SqlSessionFactory build(Reader reader, String environment, Properties properties) {
            SqlSessionFactory var5;
            try {
                XMLConfigBuilder parser = new XMLConfigBuilder(reader, environment, properties);
                var5 = this.build(parser.parse());
            } catch (Exception var14) {
                throw ExceptionFactory.wrapException("Error building SqlSession.", var14);
            } finally {
                ErrorContext.instance().reset();
                try {
                    reader.close();
                } catch (IOException var13) {
                    ;
                }
            }
            return var5;
        }

 其中最重要的是 XMLConfigBuilder 的 parse 方法，代码如下 

    public class XMLConfigBuilder extends BaseBuilder {
        public Configuration parse() {
            if (this.parsed) {
                throw new BuilderException("Each XMLConfigBuilder can only be used once.");
            } else {
                this.parsed = true;
                this.parseConfiguration(this.parser.evalNode("/configuration"));
                return this.configuration;
            }
        }
    
        private void parseConfiguration(XNode root) {
            try {
                Properties settings = this.settingsAsPropertiess(root.evalNode("settings"));
                this.propertiesElement(root.evalNode("properties"));
                this.loadCustomVfs(settings);
                this.typeAliasesElement(root.evalNode("typeAliases"));
                this.pluginElement(root.evalNode("plugins"));
                this.objectFactoryElement(root.evalNode("objectFactory"));
                this.objectWrapperFactoryElement(root.evalNode("objectWrapperFactory"));
                this.reflectorFactoryElement(root.evalNode("reflectorFactory"));
                this.settingsElement(settings);
                this.environmentsElement(root.evalNode("environments"));
                this.databaseIdProviderElement(root.evalNode("databaseIdProvider"));
                this.typeHandlerElement(root.evalNode("typeHandlers"));
                this.mapperElement(root.evalNode("mappers"));
            } catch (Exception var3) {
                throw new BuilderException("Error parsing SQL Mapper Configuration. Cause: " + var3, var3);
            }
        }
        // ...省略...
    }

parse 方法最终要返回一个 Configuration 对象，构建 Configuration 对象的建造过程都在 parseConfiguration 方法中，这也就是 Mybatis 解析 XML配置文件 来构建 Configuration对象的主要过程。所以 XMLConfigBuilder 是建造者 SqlSessionFactoryBuilder 中的建造者，复杂产品对象分别是 SqlSessionFactory 和 Configuration

