title: 访问者模式-Visitor
date: '2019-11-14 11:01:23'
updated: '2019-11-14 11:01:37'
tags: [设计模式]
permalink: /articles/2019/11/14/1573700483585.html
---
![](https://img.hacpai.com/bing/20180419.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 访问者模式-Visitor

### 什么是访问者模式

使用了一个访问者类，它改变了元素类的执行算法。通过这种方式，元素的执行算法可以随着访问者改变而改变。这种类型的设计模式属于行为型模式。根据模式，元素对象已接受访问者对象，这样访问者对象就可以处理元素对象上的操作。

### 场景

您在朋友家做客，您是访问者，朋友接受您的访问，您通过朋友的描述，然后对朋友的描述做出一个判断，这就是访问者模式。

### 示例

定义一个表示元素的接口
```
public interface ComputerPart {  
 public void accept(ComputerPartVisitor computerPartVisitor);  
}
```

创建扩展了上述类的实体类

```
public class Keyboard  implements ComputerPart {  
    
 @Override  
 public void accept(ComputerPartVisitor computerPartVisitor) {  
 computerPartVisitor.visit(this);  
 }  
}
```

```
public class Monitor  implements ComputerPart {  
    
 @Override  
 public void accept(ComputerPartVisitor computerPartVisitor) {  
 computerPartVisitor.visit(this);  
 }  
}
```

```
public class Mouse  implements ComputerPart {  
    
 @Override  
 public void accept(ComputerPartVisitor computerPartVisitor) {  
 computerPartVisitor.visit(this);  
 }  
}
```

```
public class Computer implements ComputerPart {  
    
 ComputerPart[] parts;  
    
 public Computer(){  
 parts = new ComputerPart[] {new Mouse(), new Keyboard(), new Monitor()};  
 }   
    
    
 @Override  
 public void accept(ComputerPartVisitor computerPartVisitor) {  
 for (int i = 0; i < parts.length; i++) {  
 parts[i].accept(computerPartVisitor);  
 }  
 computerPartVisitor.visit(this);  
 }  
}
```

定义一个表示访问者的接口

```
public interface ComputerPartVisitor {  
 public void visit(Computer computer);  
 public void visit(Mouse mouse);  
 public void visit(Keyboard keyboard);  
 public void visit(Monitor monitor);  
}
```

创建实现了上述类的实体访问者

```
public class ComputerPartDisplayVisitor implements ComputerPartVisitor {  
    
 @Override  
 public void visit(Computer computer) {  
 System.out.println("Displaying Computer.");  
 }  
    
 @Override  
 public void visit(Mouse mouse) {  
 System.out.println("Displaying Mouse.");  
 }  
    
 @Override  
 public void visit(Keyboard keyboard) {  
 System.out.println("Displaying Keyboard.");  
 }  
    
 @Override  
 public void visit(Monitor monitor) {  
 System.out.println("Displaying Monitor.");  
 }  
}
```

使用 ComputerPartDisplayVisitor 来显示 *Computer* 的组成部分

```
public class VisitorPatternDemo {  
 public static void main(String[] args) {  
    
 ComputerPart computer = new Computer();  
 computer.accept(new ComputerPartDisplayVisitor());  
 }  
}
```

### 典型应用

#### Spring中的应用

类BeanDefinitionVisitor
![访问者模式1.png](https://img.hacpai.com/file/2019/11/访问者模式1-df2c5b8b.png)

它的具体实现都交给了valueResolver来实现
![访问者模式2.png](https://img.hacpai.com/file/2019/11/访问者模式2-903288e4.png)
![访问者模式3.png](https://img.hacpai.com/file/2019/11/访问者模式3-c05994b7.png)

方法visitBeanDefinition实现了不同的visit来对相同的数据进行不同的处理
![访问者模式4.png](https://img.hacpai.com/file/2019/11/访问者模式4-c999ee17.png)

