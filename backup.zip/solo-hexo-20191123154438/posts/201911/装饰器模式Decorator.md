title: 装饰器模式-Decorator
date: '2019-11-12 18:18:13'
updated: '2019-11-12 18:18:13'
tags: [设计模式]
permalink: /articles/2019/11/12/1573553893300.html
---
![](https://img.hacpai.com/bing/20190923.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 装饰器模式-Decorator

### 什么是装饰器模式

允许向一个现有的对象添加新的功能，同时又不改变其结构。这种类型的设计模式属于结构型模式，它是作为现有的类的一个包装。

这种模式创建了一个装饰类，用来包装原有的类，并在保持类方法签名完整性的前提下，提供了额外的功能。

一般的，我们为了扩展一个类经常使用继承方式实现，由于继承为类引入静态特征，并且随着扩展功能的增多，子类会很膨胀。

### 场景：

1. 扩展一个类的功能。
    
2. 动态增加功能，动态撤销。
    

### 角色

* Component（抽象构件）：它是具体构件和抽象装饰类的共同父类，声明了在具体构件中实现的业务方法，它的引入可以使客户端以一致的方式处理未被装饰的对象以及装饰之后的对象，实现客户端的透明操作。
    

* ConcreteComponent（具体构件）：它是抽象构件类的子类，用于定义具体的构件对象，实现了在抽象构件中声明的方法，装饰器可以给它增加额外的职责（方法）。
    

* Decorator（抽象装饰类）：它也是抽象构件类的子类，用于给具体构件增加职责，但是具体职责在其子类中实现。它维护一个指向抽象构件对象的引用，通过该引用可以调用装饰之前构件对象的方法，并通过其子类扩展该方法，以达到装饰的目的。
    

* ConcreteDecorator（具体装饰类）：它是抽象装饰类的子类，负责向构件添加新的职责。每一个具体装饰类都定义了一些新的行为，它可以调用在抽象装饰类中定义的方法，并可以增加新的方法用以扩充对象的行为。
    

### 示例

抽象构件
```
public abstract class Display {  
​  
 abstract int getColumus();  
​  
 abstract int getRows();  
​  
 abstract String getRowsText(int row);  
​  
 final void show(){  
 for (int i = 0; i < getRows(); i++) {  
 System.out.println(getRowsText(i));  
 }  
 }  
}
```

具体构建

```
public class StringDisplay extends Display{  
 private String string;  
​  
 public StringDisplay(String string) {  
 this.string = string;  
 }  
​  
 @Override  
 int getColumus() {  
 return string.length();  
 }  
​  
 @Override  
 int getRows() {  
 return 1;  
 }  
​  
 @Override  
 String getRowsText(int row) {  
 if (row == 0){  
 return string;  
 }  
 return null;  
 }  
}
```

抽象装饰

```
public abstract class Border extends Display{  
​  
 protected Display display;  
​  
 protected Border(Display display) {  
 this.display = display;  
 }  
}
```

具体装饰

```
public class SideBorder extends Border {  
​  
 private char borderChar;  
​  
 public SideBorder(Display display, char borderChar) {  
 super(display);  
 this.borderChar = borderChar;  
 }  
​  
 @Override  
 int getColumus() {  
 return display.getColumus() + 2;  
 }  
​  
 @Override  
 int getRows() {  
 return display.getRows();  
 }  
​  
 @Override  
 String getRowsText(int row) {  
 return borderChar + display.getRowsText(row) + borderChar;  
 }  
}
```

```
public class FullBorder extends Border {  
​  
 protected FullBorder(Display display) {  
 super(display);  
 }  
​  
 @Override  
 int getColumus() {  
 return display.getColumus() + 2;  
 }  
​  
 @Override  
 int getRows() {  
 return display.getRows() + 2;  
 }  
​  
 @Override  
 String getRowsText(int row) {  
 if (row == 0) {  
 return "+" + makeLine('-', display.getColumus()) + "+";  
 } else if (row == display.getRows() + 1) {  
 return "+" + makeLine('-', display.getColumus()) + "+";  
 } else {  
 return "|" + display.getRowsText(row-1) + "|";  
 }  
 }  
​  
 private String makeLine(char ch, int count) {  
 StringBuffer sb = new StringBuffer();  
 for (int i = 0; i < count; i++) {  
 sb.append(ch);  
 }  
 return sb.toString();  
 }  
}
```

测试类

```
public class DecoratorTest {  
 public static void main(String[] args) {  
 Display d1 = new StringDisplay("hello,word");  
 Display d2 = new SideBorder(d1, '#');  
 Display d3 = new FullBorder(d2);  
 d1.show();  
 d2.show();  
 d3.show();  
 Display d4 = new SideBorder(new FullBorder(new FullBorder(new SideBorder(new FullBorder(new StringDisplay("你好，世界")), '*'))), '/');  
 d4.show();  
 }  
}
```

### 典型应用

#### Java I/O中的装饰者模式

使用 Java I/O 的时候总是有各种输入流、输出流、字符流、字节流、过滤流、缓冲流等等各种各样的流，不熟悉里边的设计模式的话总会看得云里雾里的，现在通过设计模式的角度来看 Java I/O，会好理解很多。

先用一幅图来看看Java I/O到底是什么，下面的这幅图生动的刻画了Java I/O的作用。  
![装饰器1.png](https://img.hacpai.com/file/2019/11/装饰器1-8f0a02c0.png)

由上图可知在Java中应用程序通过输入流（InputStream）的Read方法从源地址处读取字节，然后通过输出流（OutputStream）的Write方法将流写入到目的地址。

流的来源主要有三种：本地的文件（File）、控制台、通过socket实现的网络通信

下面的图可以看出Java中的装饰者类和被装饰者类以及它们之间的关系，这里只列出了InputStream中的关系：  
![装饰器2.png](https://img.hacpai.com/file/2019/11/装饰器2-31d9cb9b.png)

#### Mybatis 缓存中的装饰者模式

org.apache.ibatis.cache 包的文件结构如下所示
![装饰器3.png](https://img.hacpai.com/file/2019/11/装饰器3-552b3d02.png)

我们通过类所在的包名即可判断出该类的角色，Cache 为抽象构件类，PerpetualCache 为具体构件类，decorators 包下的类为装饰类，没有抽象装饰类

通过名称也可以判断出装饰类所要装饰的功能
