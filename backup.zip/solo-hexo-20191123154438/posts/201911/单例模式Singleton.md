title: 单例模式-Singleton
date: '2019-11-05 16:45:55'
updated: '2019-11-05 16:45:55'
tags: [设计模式]
permalink: /articles/2019/11/05/1572943555619.html
---
# 单例模式-Singleton

### 什么是单例模式？

确保某个类在任何情况下只生成一个实例的模式成为单例模式

### 单例模式有三个要点：

1. 构造方法私有化；
    
2. 实例化的变量引用私有化；
    
3. 获取实例的方法共有
    

### 单例模式种类：

* 懒汉式
    
* 饿汉式
    
* 静态内部类
    

饿汉式：

```
/**  
 * 饿汉式  
 */  
public class Singleton {  
 private static Singleton singleton = new Singleton();  
​  
 private Singleton() {  
 System.out.println("创建实例");  
 }  
​  
 public static Singleton getInstance(){  
 return singleton;  
 }  
}
```
懒汉式：
```
/**  
 * 懒汉式  
 */  
public class Singleton1 {  
​  
 private static Singleton1 singleton ;  
​  
 private Singleton1() {  
 System.out.println("创建实例");  
 }  
​  
 public static Singleton1 getInstance(){  
 if (null == singleton){  
 singleton = new Singleton1();  
 }  
 return singleton;  
 }  
}
```
静态内部类：
```
/**  
 * 静态内部类  
 */  
public class Singleton2 {  
​  
 private Singleton2() {}  
​  
 private static class SingletonInstance {  
 private static final Singleton2 INSTANCE = new Singleton2();  
 }  
​  
 public static Singleton2 getInstance() {  
 return SingletonInstance.INSTANCE;  
 }  
}
```

### 总结：

单例模式作为一种目标明确、结构简单、理解容易的设计模式，在软件开发中使用频率相当高，在很多应用软件和框架中都得以广泛应用。

### 单例模式的典型应用

### JDK Runtime 饿汉单例

JDK Runtime类代表着Java程序的运行时环境，每个Java程序都有一个Runtime实例，该类会被自动创建，我们可以通过 Runtime.getRuntime() 方法来获取当前程序的Runtime实例。一旦得到了一个当前的Runtime对象的引用，就可以调用Runtime对象的方法去控制Java虚拟机的状态和行为。
```
public class Runtime {  
 private static Runtime currentRuntime = new Runtime();  
​  
 public static Runtime getRuntime() {  
 return currentRuntime;  
 }  
}
```
