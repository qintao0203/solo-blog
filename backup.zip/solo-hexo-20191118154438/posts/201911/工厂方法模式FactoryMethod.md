title: 工厂方法模式-Factory Method
date: '2019-11-05 16:14:39'
updated: '2019-11-05 16:15:26'
tags: [设计模式]
permalink: /articles/2019/11/05/1572941679915.html
---
![](https://img.hacpai.com/bing/20180828.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 工厂方法模式-Factory Method

### 什么是工厂方法模式？

工厂方法模式，又称工厂模式、多态工厂模式和虚拟构造器模式，通过定义工厂父类负责定义创建对象的公共接口，而子类则负责生成具体的对象。

#### 场景：

主要用于将类的实例化延迟导工厂类的子类中完成，即由子类来决定实例化哪一个类。

### 示例：

生成实例的框架：
```
public abstract class Factory {  
 public final Product create(String owner){  
 Product p = createProduct(owner);  
 reginsterProduct(p);  
 return p;  
 }  
​  
 protected abstract Product createProduct(String owner);  
 protected abstract void reginsterProduct(Product product);  
​  
}
```
```
/**  
 * 定义实例所持有的接口  
 */  
public abstract class Product {  
​  
 public abstract void use();  
}
```


负责处理的子类：
```
/**  
 * 具体创建实例由子类实现，这样可以防止父类与其他具体类耦合  
 */  
public class IDCard extends Product {  
​  
 private String owner;  
​  
 IDCard(String owner){  
 System.out.println("制作"+owner+"的ID卡");  
 this.owner = owner;  
 }  
​  
 @Override  
 public void use() {  
 System.out.println("使用" +owner+"的ID卡");  
​  
 }  
​  
 public String getOwner(){  
 return owner;  
 }  
}
```
```
public class IDCardFactory extends Factory {  
 private List owners = new ArrayList();  
 @Override  
 protected Product createProduct(String owner) {  
 return new IDCard(owner);  
 }  
​  
 @Override  
 protected void reginsterProduct(Product product) {  
 owners.add(((IDCard)product).getOwner());  
 }  
​  
 public List getOwners(){  
 return owners;  
 }  
}
```


测试类：
```
public class FactoryMethodTest {  
​  
 public static void main(String[] args) {  
 Factory factory  = new IDCardFactory();  
 Product product = factory.create("小红");  
 Product product1 = factory.create("小名");  
 Product product2 = factory.create("小君");  
 product.use();  
 product1.use();  
 product2.use();  
​  
 }  
}
```


### 总结：

工厂模式可以说是简单工厂模式的进一步抽象和拓展，在保留了简单工厂的封装优点的同时，让扩展变得简单，让继承变得可行，增加了多态性的体现。

springbean中的应用：
```
FactoryBean中定义了三个基础的bean应具有的方法

T getObject() throws Exception;    //返回此工厂管理的对象的实例  
Class<?> getObjectType();    //返回此FactoryBean创建的对象的类型  
//这个工厂返回的对象是否是单例，默认返回true；若是单例则由getObject返回的//是相同的对象，是可以缓存的引用  
default boolean isSingleton() {   
 return true;  
}
```
AbstractFactoryBean实现了FactoryBean并且扩展了一些功能，而抽象类中并未具体实现创建bean的方法，交给了具体的实例去实现，各个扩展功能基于此创建自己需要的bean实例。

```
 @Override  
 public abstract Class<?> getObjectType();  
​  
 protected abstract T createInstance() throws Exception;
```

spring-data中大量使用了这一功能,如spring-data-mongo中创建MongoClient的实现：
```
/*  
 * (non-Javadoc)  
 * @see org.springframework.beans.factory.config.AbstractFactoryBean#createInstance()  
 */  
 @Override  
 protected MongoClient createInstance() throws Exception {  
​  
 if (mongoClientOptions == null) {  
 mongoClientOptions = MongoClientOptions.builder().build();  
 }  
​  
 return createMongoClient();  
 }
```

