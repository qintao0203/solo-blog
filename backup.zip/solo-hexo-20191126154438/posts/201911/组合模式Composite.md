title: 组合模式-Composite
date: '2019-11-12 15:58:52'
updated: '2019-11-12 15:59:05'
tags: [设计模式]
permalink: /articles/2019/11/12/1573545532626.html
---
![](https://img.hacpai.com/bing/20171105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

组合模式-Composite

什么是组合模式

 组合模式（Composite Pattern），又叫部分整体模式，是用于把一组相似的对象当作一个单一的对象。组合模式依据树形结构来组合对象，用来表示部分以及整体层次。这种类型的设计模式属于结构型模式，它创建了对象组的树形结构。 

场景

 它在我们树型结构的问题中，模糊了简单元素和复杂元素的概念，客户程序可以像处理简单元素一样来处理复杂元素，从而使得客户程序与复杂元素的内部结构解耦。 

角色

- Component（抽象构件）：它可以是接口或抽象类，为叶子构件和容器构件对象声明接口，在该角色中可以包含所有子类共有行为的声明和实现。在抽象构件中定义了访问及管理它的子构件的方法，如增加子构件、删除子构件、获取子构件等。

- Leaf（叶子构件）：它在组合结构中表示叶子节点对象，叶子节点没有子节点，它实现了在抽象构件中定义的行为。对于那些访问及管理子构件的方法，可以通过异常等方式进行处理。

- Composite（容器构件）：它在组合结构中表示容器节点对象，容器节点包含子节点，其子节点可以是叶子节点，也可以是容器节点，它提供一个集合用于存储子节点，实现了在抽象构件中定义的行为，包括那些访问及管理子构件的方法，在其业务方法中可以递归调用其子节点的业务方法。

示例

文件夹以及文件类：

    /**
     * 目录节点
     * 包含：
     *         1、目录名
     *         2、下级文件列表
     *         3、下级目录列表
     *         4、新增文件方法
     *         5、新增目录方法
     *         6、显示下级内容方法
     */
    public class Noder {
        String nodeName;//目录名
        //通过构造器为目录命名
        public Noder(String nodeName){
            this.nodeName = nodeName;
        }
        List<Noder> nodeList = new ArrayList<Noder>();//目录的下级目录列表
        List<Filer> fileList = new ArrayList<Filer>();//目录的下级文件列表
        //新增下级目录
        public void addNoder(Noder noder){
            nodeList.add(noder);
        }
        //新增文件
        public void addFiler(Filer filer){
            fileList.add(filer);
        }
        //显示下级目录及文件
        public void display(){
            for(Noder noder:nodeList){
                System.out.println(noder.nodeName);
                noder.display();//递归显示目录列表
            }
            for(Filer filer:fileList){
                filer.display();
            }
        }
    }

    /**
     * 文件节点
     * 文件节点是终节点，无下级节点
     * 包含：
     *         1、文件名
     *         2、文件显示方法
     */
    public class Filer {
        String fileName;//文件名
        public Filer(String fileName){
            this.fileName = fileName;
        }
        //文件显示方法
        public void display(){
            System.out.println(fileName);
        }
    }

测试类：

    public class Clienter {
        public static void createTree(Noder node){
            File file = new File(node.nodeName);
            File[] f = file.listFiles();
            for(File fi : f){
                if(fi.isFile()){
                    Filer filer = new Filer(fi.getAbsolutePath());
                    node.addFiler(filer);
                }
                if(fi.isDirectory()){
                    Noder noder = new Noder(fi.getAbsolutePath());
                    node.addNoder(noder);
                    createTree(noder);//使用递归生成树结构
                }
            }
        }
        public static void main(String[] args) {
            Noder noder = new Noder("E://BaiduNetdiskDownload");
            createTree(noder);//创建目录树形结构
            noder.display();//显示目录及文件
        }
    }

典型应用

Mybatis SqlNode中的组合模式

MyBatis 的强大特性之一便是它的动态SQL，其通过 if, choose, when, otherwise, trim, where, set, foreach 标签，可组合成非常灵活的SQL语句，从而提高开发人员的效率。

动态SQL – IF 

    <select id="findActiveBlogLike"  resultType="Blog">
      SELECT * FROM BLOG WHERE state = ‘ACTIVE’ 
      <if test="title != null">
        AND title like #{title}
      </if>
      <if test="author != null and author.name != null">
        AND author_name like #{author.name}
      </if>
    </select>
    

动态SQL – choose, when, otherwise 

    <select id="findActiveBlogLike"  resultType="Blog">
      SELECT * FROM BLOG WHERE state = ‘ACTIVE’
      <choose>
        <when test="title != null">
          AND title like #{title}
        </when>
        <when test="author != null and author.name != null">
          AND author_name like #{author.name}
        </when>
        <otherwise>
          AND featured = 1
        </otherwise>
      </choose>
    </select>

 动态SQL – where 

    <select id="findActiveBlogLike"  resultType="Blog">
      SELECT * FROM BLOG 
      <where> 
        <if test="state != null">
             state = #{state}
        </if> 
        <if test="title != null">
            AND title like #{title}
        </if>
        <if test="author != null and author.name != null">
            AND author_name like #{author.name}
        </if>
      </where>
    </select>

Mybatis在处理动态SQL节点时，应用到了组合设计模式，Mybatis会将映射配置文件中定义的动态SQL节点、文本节点等解析成对应的 SqlNode 实现，并形成树形结构。

SQLNode` 的类图如下所示
![组合模式1.jpg](https://img.hacpai.com/file/2019/11/组合模式1-e248f780.jpg)


需要先了解 DynamicContext 类的作用：主要用于记录解析动态SQL语句之后产生的SQL语句片段，可以认为它是一个用于记录动态SQL语句解析结果的容器 

抽象构件为 SqlNode 接口，源码如下:

    public interface SqlNode {
      boolean apply(DynamicContext context);
    }	

apply 是 SQLNode 接口中定义的唯一方法，该方法会根据用户传入的实参，参数解析该SQLNode所记录的动态SQL节点，并调用 DynamicContext.appendSql() 方法将解析后的SQL片段追加到 DynamicContext.sqlBuilder 中保存，当SQL节点下所有的 SqlNode 完成解析后，我们就可以从 DynamicContext 中获取一条动态生产的、完整的SQL语句

然后来看 MixedSqlNode 类的源码：

    public class MixedSqlNode implements SqlNode {
      private List<SqlNode> contents;
    
      public MixedSqlNode(List<SqlNode> contents) {
        this.contents = contents;
      }
    
      @Override
      public boolean apply(DynamicContext context) {
        for (SqlNode sqlNode : contents) {
          sqlNode.apply(context);
        }
        return true;
      }
    }

MixedSqlNode 维护了一个 List<SqlNode> 类型的列表，用于存储 SqlNode 对象，apply 方法通过 for循环 遍历 contents 并调用其中对象的 apply 方法，很明显 MixedSqlNode 扮演了容器构件角色

对于其他SqlNode子类的功能，稍微概括如下：

TextSqlNode：表示包含 {} 占位符的动态SQL节点，其 apply 方法会使用 GenericTokenParser 解析 {} 占位符，并直接替换成用户给定的实际参数值
IfSqlNode：对应的是动态SQL节点 <If> 节点，其 apply 方法首先通过 ExpressionEvaluator.evaluateBoolean() 方法检测其 test 表达式是否为 true，然后根据 test 表达式的结果，决定是否执行其子节点的 apply() 方法
TrimSqlNode ：会根据子节点的解析结果，添加或删除相应的前缀或后缀。
WhereSqlNode 和 SetSqlNode 都继承了 TrimSqlNode
ForeachSqlNode：对应 <foreach> 标签，对集合进行迭代
动态SQL中的 <choose>、<when>、<otherwise> 分别解析成 ChooseSqlNode、IfSqlNode、MixedSqlNode
综上，SqlNode 接口有多个实现类，每个实现类对应一个动态SQL节点，其中 SqlNode 扮演抽象构件角色，MixedSqlNode 扮演容器构件角色，其它一般是叶子构件角色



