title: 模板方法模式-Template Method
date: '2019-11-05 11:38:30'
updated: '2019-11-05 12:05:17'
tags: [设计模式]
permalink: /articles/2019/11/05/1572925110742.html
---
![](https://img.hacpai.com/bing/20180410.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 模板方法模式-Template Method

### 什么是模板方法模式？

在父类中定义处理流程的框架，在子类中实现具体处理的模式成为模板方法模式

场景：

在处理一些流程类似，而具体方法实现可能不同的情况下使用模板方法，父类定义方法，以及实现处理流程的方法，子类根据场景实现具体方法。

### 示例：

抽象父类：

```
public abstract class AbstractDisplay {  
 public abstract void open();  
​  
 public abstract void close();  
​  
 public abstract void print();  
​  
 /**  
 * 处理流程  
 */  
 public final void display() {  
 open();  
 for (int i = 0; i < 5; i++) {  
 print();  
 }  
 close();  
 }  
}
```
具体子类实现：
```
public class CharDisplay extends AbstractDisplay {  
​  
 private char ch;  
​  
 public CharDisplay(char ch) {  
 this.ch = ch;  
 }  
​  
 @Override  
 public void open() {  
 System.out.println("<<");  
 }  
​  
 @Override  
 public void close() {  
 System.out.println(">>");  
 }  
​  
 @Override  
 public void print() {  
​  
 System.out.println(ch);  
 }  
}  
​  
public class StringDisplay extends AbstractDisplay {  
 private String string;  
 private int width;  
​  
 public StringDisplay(String string) {  
 this.string = string;  
 this.width = string.getBytes().length;  
 }  
​  
 @Override  
 public void open() {  
 printLine();  
 }  
​  
 @Override  
 public void close() {  
 printLine();  
 }  
​  
 @Override  
 public void print() {  
 System.out.println("|" + string + "|");  
 }  
​  
 private void printLine() {  
 System.out.print("+");  
 for (int i = 0; i < width; i++) {  
 System.out.print("-");  
 }  
 System.out.print("+");  
 }  
}  
```

测试类：
```
public class AbstractDisplayTest {  
​  
 public static void main(String[] args) {  
 AbstractDisplay display = new CharDisplay('H');  
 AbstractDisplay display1 = new StringDisplay("你好");  
 AbstractDisplay display2 = new StringDisplay("Hello word!");  
 display.display();  
 display1.display();  
 display2.display();  
 }  
}
```
### 优点：

父类中编写了模板方法算法，无需在子类中重复再编写算法。

### 里氏替换原则：

在测试类中，使用父类类型保存子类的实例的优点，即使没有使用instanceof等指定子类种类，程序也能正常工作，这种称为里氏替换原则（The Liskov Substitution Principle LSP）

### 源码分析模板方法模式的典型应用

#### Servlet 中的模板方法模式

Servlet（Server Applet）是Java Servlet的简称，用Java编写的服务器端程序，主要功能在于交互式地浏览和修改数据，生成动态Web内容。在每一个 Servlet 都必须要实现 Servlet 接口，GenericServlet 是个通用的、不特定于任何协议的Servlet，它实现了 Servlet 接口，而 HttpServlet 继承于 GenericServlet，实现了 Servlet 接口，为 Servlet 接口提供了处理HTTP协议的通用实现，所以我们定义的 Servlet 只需要继承 HttpServlet 即可。

![HttpServletçç»§æ¿å³ç³»](http://image.laijianfeng.org/20181010_214703.png)

`HttpServlet` 的简要代码如下所示
```
public abstract class HttpServlet extends GenericServlet {  
 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doDelete(HttpServletRequest req,  HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
 protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 // ...  
 }  
   
 protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {  
 String method = req.getMethod();  
​  
 if (method.equals(METHOD_GET)) {  
 long lastModified = getLastModified(req);  
 if (lastModified == -1) {  
 // servlet doesn't support if-modified-since, no reason  
 // to go through further expensive logic  
 doGet(req, resp);  
 } else {  
 long ifModifiedSince = req.getDateHeader(HEADER_IFMODSINCE);  
 if (ifModifiedSince < lastModified) {  
 // If the servlet mod time is later, call doGet()  
 // Round down to the nearest second for a proper compare  
 // A ifModifiedSince of -1 will always be less  
 maybeSetLastModified(resp, lastModified);  
 doGet(req, resp);  
 } else {  
 resp.setStatus(HttpServletResponse.SC_NOT_MODIFIED);  
 }  
 }  
​  
 } else if (method.equals(METHOD_HEAD)) {  
 long lastModified = getLastModified(req);  
 maybeSetLastModified(resp, lastModified);  
 doHead(req, resp);  
​  
 } else if (method.equals(METHOD_POST)) {  
 doPost(req, resp);  
   
 } else if (method.equals(METHOD_PUT)) {  
 doPut(req, resp);  
   
 } else if (method.equals(METHOD_DELETE)) {  
 doDelete(req, resp);  
   
 } else if (method.equals(METHOD_OPTIONS)) {  
 doOptions(req,resp);  
   
 } else if (method.equals(METHOD_TRACE)) {  
 doTrace(req,resp);  
   
 } else {  
 //  
 // Note that this means NO servlet supports whatever  
 // method was requested, anywhere on this server.  
 //  
​  
 String errMsg = lStrings.getString("http.method_not_implemented");  
 Object[] errArgs = new Object[1];  
 errArgs[0] = method;  
 errMsg = MessageFormat.format(errMsg, errArgs);  
   
 resp.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED, errMsg);  
 }  
 }  
   
 // ...省略...  
}
```
在 HttpServlet 的 service 方法中，首先获得到请求的方法名，然后根据方法名调用对应的 doXXX 方法，比如说请求方法为GET，那么就去调用 doGet 方法；请求方法为POST，那么就去调用 doPost 方法

HttpServlet 相当于定义了一套处理 HTTP 请求的模板；service 方法为模板方法，定义了处理HTTP请求的基本流程；doXXX 等方法为基本方法，根据请求方法做相应的处理，子类可重写这些方法；HttpServletRequest 中的Method则起到钩子方法的作用.

在开发javaWeb应用时，自定义的Servlet类一般都扩展 HttpServlet 类，譬如我们实现一个输出 Hello World! 的 Servlet 如下
```
import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
​  
// 扩展 HttpServlet 类  
public class HelloWorld extends HttpServlet {  
​  
 public void init() throws ServletException {  
 // ...  
 }  
​  
 public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
 response.setContentType("text/html");  
 PrintWriter out = response.getWriter();  
 out.println("<h1>Hello World!</h1>");  
 }  
   
 public void destroy() {  
 // ...  
 }  
}
```
该自定义的 `Servlet` 重写了 `doGet` 方法，当客户端发起 GET 请求时将得到 `Hello World!`。

#### Mybatis BaseExecutor接口中的模板方法模式

`Executor` 是 Mybatis 的核心接口之一，其中定义了数据库操作的基本方法，该接口的代码如下：
```
public interface Executor {  
​  
 ResultHandler NO_RESULT_HANDLER = null;  
 // 执行 update、insert、delete 三种类型的SQL语句  
 int update(MappedStatement ms, Object parameter) throws SQLException;  
 // 执行selete类型的SQL语句，返回值分为结果对象列表或游标对象  
 <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey cacheKey, BoundSql boundSql) throws SQLException;  
 /  
 <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler) throws SQLException;  
​  
 <E> Cursor<E> queryCursor(MappedStatement ms, Object parameter, RowBounds rowBounds) throws SQLException;   
 // 批量执行SQL语句  
 List<BatchResult> flushStatements() throws SQLException;  
 // 提交事务  
 void commit(boolean required) throws SQLException;  
 // 回滚事务  
 void rollback(boolean required) throws SQLException;  
 // 创建缓存中用到的CacheKey对象  
 CacheKey createCacheKey(MappedStatement ms, Object parameterObject, RowBounds rowBounds, BoundSql boundSql);  
 // 根据CacheKey对象查找缓存  
 boolean isCached(MappedStatement ms, CacheKey key);  
 // 清空一级缓存  
 void clearLocalCache();  
 // 延迟加载一级缓存中的数据  
 void deferLoad(MappedStatement ms, MetaObject resultObject, String property, CacheKey key, Class<?> targetType);  
 // 获取事务对象  
 Transaction getTransaction();  
 // 关闭Executor对象  
 void close(boolean forceRollback);  
 // 检测Executor是否已关闭  
 boolean isClosed();  
​  
 void setExecutorWrapper(Executor executor);  
​  
}
```
`Executor` 类的类图如下 ![Executorä¸å¶å­ç±»çç±»å¾](http://image.laijianfeng.org/20181010_214704.png)

BaseExecutor 中主要提供了缓存管理和事务管理的基本功能，继承 BaseExecutor 的子类只需要实现四个基本方法来完成数据库的相关操作即可，这四个方法分别是：doUpdate() 方法、doQuery() 方法、doQueryCursor() 方法、doFlushStatement() 方法，其余功能都在 BaseExecutor 中实现。

BaseExecutor的部分代码如下，其中的 query() 方法首先会创建 CacheKey 对象，并根据 CacheKey 对象查找一级缓存，如果缓存命中则返回缓存中记录的结果对象，如果未命中则查询数据库得到结果集，之后将结果集映射成结果对象并保存到一级缓存中，同时返回结果对象。
```
public abstract class BaseExecutor implements Executor {  
 protected Transaction transaction;  
 protected Executor wrapper;  
​  
 protected ConcurrentLinkedQueue<DeferredLoad> deferredLoads;  
 protected PerpetualCache localCache;  
 protected PerpetualCache localOutputParameterCache;  
 protected Configuration configuration;  
​  
 protected int queryStack = 0;  
 private boolean closed;  
   
 @Override  
 public <E> List<E> query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql) throws SQLException {  
 ErrorContext.instance().resource(ms.getResource()).activity("executing a query").object(ms.getId());  
 if (closed) {  
 throw new ExecutorException("Executor was closed.");  
 }  
 if (queryStack == 0 && ms.isFlushCacheRequired()) {  
 clearLocalCache();  
 }  
 List<E> list;  
 try {  
 queryStack++;  
 list = resultHandler == null ? (List<E>) localCache.getObject(key) : null;  
 if (list != null) {  
 handleLocallyCachedOutputParameters(ms, key, parameter, boundSql);  
 } else {  
 list = queryFromDatabase(ms, parameter, rowBounds, resultHandler, key, boundSql);  
 }  
 } finally {  
 queryStack--;  
 }  
 if (queryStack == 0) {  
 for (DeferredLoad deferredLoad : deferredLoads) {  
 deferredLoad.load();  
 }  
 // issue #601  
 deferredLoads.clear();  
 if (configuration.getLocalCacheScope() == LocalCacheScope.STATEMENT) {  
 // issue #482  
 clearLocalCache();  
 }  
 }  
 return list;  
 }  
   
 protected abstract int doUpdate(MappedStatement ms, Object parameter)  
 throws SQLException;  
​  
 protected abstract List<BatchResult> doFlushStatements(boolean isRollback)  
 throws SQLException;  
​  
 protected abstract <E> List<E> doQuery(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql)  
 throws SQLException;  
​  
 protected abstract <E> Cursor<E> doQueryCursor(MappedStatement ms, Object parameter, RowBounds rowBounds, BoundSql boundSql)  
 throws SQLException;  
​  
 // 省略....  
}
```
BaseExecutor 的子类有四个分别是 SimpleExecotor、ReuseExecutor、BatchExecutor、ClosedExecutor，由于这里使用了模板方法模式，一级缓存等固定不变的操作都封装到了 BaseExecutor 中，因此子类就不必再关心一级缓存等操作，只需要专注实现4个基本方法的实现即可。

这里对这四个子类的功能做一个简要的介绍：

* SimpleExecutor 是Mybatis执行Mapper语句时默认使用的 Executor，提供最基本的Mapper语句执行功能，没有过多的封装的
    
* ReuseExecutor 提供了 Statement 重用的功能，通过 statementMap 字段缓存使用过的 Statement 对象进行重用，可以减少SQL预编译以及创建和销毁 Statement 对象的开销，从而提高性能
    
* BatchExecutor 实现了批处理多条SQL语句的功能，在客户端缓存多条SQL并在合适的时机将多条SQL打包发送给数据库执行，从而减少网络方面的开销，提升系统的性能
    
* ClosedExecutor 只是某个类的一个内部类
    

参考：

图解设计模式

图解设计模式

CSDN博主「小旋锋」  原文链接： [https://blog.csdn.net/wwwdc1012/article/details/83005717](https://blog.csdn.net/wwwdc1012/article/details/83005717)
